from __future__ import annotations
import os
from datetime import datetime, timezone
from typing import Optional
import pandas as pd
from .schemas import (
    Case, Activity, Rule, StateEvent, Record
)

def _parse_dt(val) -> Optional[datetime]:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    s = str(val).strip()
    if not s or s.lower() in ("nan", "none", ""):
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S"):
            try:
                return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
            except Exception:
                pass
    return None


def load_requests(path: str) -> list[Case]:
    df = pd.read_csv(path, dtype=str).fillna("")
    cases: list[Case] = []
    for _, row in df.iterrows():
        audit_at = _parse_dt(row.get("audit_at"))
        if audit_at is None:
            audit_at = _parse_dt(row.get("reported_at"))
        if audit_at is None:
            audit_at = _parse_dt(row.get("requested_at"))
        cases.append(Case(
            case_id=row["case_id"],
            email=(row.get("email") or "").strip().lower(),
            requested_at=_parse_dt(row.get("requested_at")) or datetime.now(timezone.utc),
            reported_status=(row.get("reported_status") or "").strip().upper(),
            reported_at=_parse_dt(row.get("reported_at")),
            audit_at=audit_at or datetime.now(timezone.utc),
            request_text=(row.get("request_text") or ""),
        ))
    return cases


def load_identities(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    return df.to_dict(orient="records")


def load_audit_log(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    rows = []
    for _, row in df.iterrows():
        ts = _parse_dt(row.get("changed_at") or row.get("timestamp") or row.get("audit_at"))
        rows.append({
            "ts": ts,
            "old_value": (row.get("old_value") or row.get("old") or "").strip().lower(),
            "new_value": (row.get("new_value") or row.get("new") or "").strip().lower(),
            "identifier_type": (row.get("identifier_type") or row.get("field") or "").strip().lower(),
            "user_id": (row.get("user_id") or "").strip(),
            "audit_id": (row.get("audit_id") or "").strip(),
        })
    return rows


def load_activity(path: str) -> list[Activity]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    out: list[Activity] = []
    for _, row in df.iterrows():
        kind = (row.get("activity_type") or row.get("kind") or row.get("type") or "other").strip().lower()
        if kind not in ("delete", "sync", "import", "export", "index", "backup", "restore", "other"):
            kind = "other"
        status = (row.get("status") or "").strip().lower()
        if status not in ("active", "inactive", "completed", "failed"):
            status = "completed" if row.get("ended_at") else "active"
        scope = {}
        cats = (row.get("data_categories") or row.get("data_category") or "").strip()
        if cats:
            scope["data_categories"] = [c.strip() for c in cats.split(",") if c.strip()]
        urefs = (row.get("user_refs") or row.get("user_ref") or row.get("email") or "").strip()
        if urefs:
            scope["user_refs"] = [u.strip().lower() for u in urefs.split(",") if u.strip()]
        out.append(Activity(
            activity_id=(row.get("activity_id") or "").strip(),
            system_id=(row.get("system_id") or "").strip(),
            kind=kind,
            status=status,
            started_at=_parse_dt(row.get("started_at") or row.get("requested_at") or row.get("audit_at")) or datetime.now(timezone.utc),
            ended_at=_parse_dt(row.get("ended_at")),
            scope=scope,
            evidence_id=(row.get("evidence_id") or row.get("activity_id") or "").strip(),
        ))
    return out


def load_rules(path: str) -> dict[str, Rule]:
    if not os.path.exists(path):
        return {}
    df = pd.read_csv(path, dtype=str).fillna("")
    out: dict[str, Rule] = {}
    for _, row in df.iterrows():
        cat = (row.get("data_category") or "").strip()
        if not cat:
            continue
        treatment = (row.get("treatment") or row.get("action") or "RETAIN").strip().upper()
        if treatment not in ("DELETE", "REDACT", "ANONYMIZE", "RETAIN"):
            treatment = "RETAIN"
        fields = [f.strip() for f in (row.get("fields_to_remove") or "").split(",") if f.strip()]
        keep = [f.strip() for f in (row.get("keep_fields") or "").split(",") if f.strip()]
        is_tomb = (row.get("is_tombstone") or "").strip().lower() in ("true", "1", "yes")
        out[cat] = Rule(
            data_category=cat, treatment=treatment,
            fields_to_remove=fields, keep_fields=keep, is_tombstone=is_tomb,
        )
    return out


def load_evidence_manifest(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    return df.to_dict(orient="records")