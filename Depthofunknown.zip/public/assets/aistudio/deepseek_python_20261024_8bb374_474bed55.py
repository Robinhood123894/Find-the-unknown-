from __future__ import annotations
import os, json
from typing import Protocol, Optional
from pydantic import BaseModel
from audit.ai.usage import log_call

class LLMClient(Protocol):
    def extract_json(self, prompt: str, schema: type[BaseModel], *, model: str, temperature: float = 0) -> Optional[BaseModel]: ...
    def classify_log_lines(self, lines: list[str], model: str, temperature: float = 0) -> list[dict]: ...
    def verify_case(self, bundle: dict, model: str, temperature: float = 0) -> dict: ...
    def classify_na(self, request_text: str, reported_status: str, model: str, temperature: float = 0) -> bool: ...


def _estimate_cost(model: str, in_tok: int, out_tok: int) -> float:
    prices = {
        "gpt-4o": (2.50 / 1_000_000, 10.00 / 1_000_000),
        "gpt-4o-mini": (0.15 / 1_000_000, 0.60 / 1_000_000),
    }
    pin, pout = prices.get(model, (0.0, 0.0))
    return in_tok * pin + out_tok * pout


class OpenAIClient:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._client = None
        if self.api_key:
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=self.api_key)
            except Exception:
                self._client = None

    def _safe(self):
        return self._client is not None

    def _complete(self, phase: str, model: str, temperature: float, messages: list[dict], json_mode: bool = True) -> Optional[dict]:
        if not self._safe():
            return None
        try:
            kwargs = dict(model=model, temperature=temperature, messages=messages)
            if json_mode:
                kwargs["response_format"] = {"type": "json_object"}
            resp = self._client.chat.completions.create(**kwargs)
            in_tok = getattr(resp.usage, "prompt_tokens", 0) or 0
            out_tok = getattr(resp.usage, "completion_tokens", 0) or 0
            log_call(phase=phase, provider="openai", model=model,
                     input_tokens=in_tok, output_tokens=out_tok,
                     est_cost=_estimate_cost(model, in_tok, out_tok))
            content = resp.choices[0].message.content
            try:
                return json.loads(content)
            except Exception:
                return None
        except Exception:
            return None

    def extract_json(self, prompt, schema, *, model, temperature=0):
        data = self._complete("vision_extract", model, temperature,
                              [{"role": "user", "content": prompt}])
        if not data:
            return None
        try:
            return schema.model_validate(data)
        except Exception:
            return None

    def classify_log_lines(self, lines, model, temperature=0):
        if not lines:
            return []
        prompt = (
            "Classify each log line into strict JSON list. Each item: "
            "{event_type: CREATE|DELETE|REDACT|ANONYMIZE|RESTORE|SYNC_WRITE|INDEX|EXPORT|other, "
            "system_id:str, resource_id:str, user_ref:str, ts:ISO8601-or-null}. "
            "Return {\"items\":[...]}.\n\nLINES:\n" + "\n".join(lines)
        )
        data = self._complete("log_interpret", model, temperature,
                              [{"role": "user", "content": prompt}])
        if not data:
            return []
        return data.get("items", [])

    def verify_case(self, bundle, model, temperature=0):
        prompt = (
            "You are an auditor. Given this compact case bundle (JSON), return strict JSON "
            "{\"missed\":[{system_id,resource_id,kind}], \"invalid\":[{system_id,resource_id,reason}]}. "
            "Do NOT rewrite steps. Only name targets.\n\nBUNDLE:\n" + json.dumps(bundle, default=str)
        )
        data = self._complete("verifier", model, temperature,
                              [{"role": "user", "content": prompt}])
        if not data:
            return {"missed": [], "invalid": []}
        return data

    def classify_na(self, request_text, reported_status, model, temperature=0):
        prompt = (
            "Return strict JSON {\"is_deletion\": true|false, \"reason\": str}. "
            "Decide if request_text is an authorized personal-data deletion request. "
            f"reported_status={reported_status!r}\nrequest_text={request_text!r}"
        )
        data = self._complete("na_classifier", model, temperature,
                              [{"role": "user", "content": prompt}])
        if not data:
            return False
        return bool(data.get("is_deletion", False))


class NullClient:
    """Used when no API key — deterministic only."""
    def extract_json(self, *a, **k): return None
    def classify_log_lines(self, *a, **k): return []
    def verify_case(self, *a, **k): return {"missed": [], "invalid": []}
    def classify_na(self, *a, **k): return False