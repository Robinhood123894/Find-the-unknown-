import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck, AlertTriangle, CheckCircle2, XCircle, Play, FileText,
  Database, Code, Cpu, RefreshCw, Download, Sparkles, Filter, ChevronRight,
  ExternalLink, Layers, ArrowRight, UserCheck, Wrench, Search, Check, Copy,
  Info, AlertOctagon, Terminal, UploadCloud, FileSpreadsheet, Eye, HelpCircle,
  Scale, Bot, GitCommit, Split, KeyRound, Lock, AlertCircle
} from 'lucide-react';

interface CaseResult {
  case_id: string;
  deletion_status: 'COMPLETE' | 'INCOMPLETE' | 'NOT_APPLICABLE' | 'KEY_ABSENT';
  steps: Array<{
    step_no: number;
    phase: 'FINDING' | 'REMEDIATION' | 'VERIFICATION';
    system_id: string;
    resource_id: string;
    operation: string;
    state: string;
    evidence_id?: string;
  }>;
}

interface DiffRow {
  case_id: string;
  status_A: string;
  status_B: string;
  status_same: string;
  steps_same: string;
  suggested_decision: string;
}

interface FileMeta {
  sourceName: string;
  targetPath: string;
  description: string;
  category: string;
  lines: number;
  bytes: number;
  content: string;
}

const TEMPLATES: Record<string, string> = {
  'deletion_requests.csv': `case_id,email,requested_at,reported_status,reported_at,audit_at,request_text
CASE-101,user1@example.com,2026-10-01T10:00:00Z,COMPLETE,2026-10-02T12:00:00Z,2026-10-05T00:00:00Z,"Please delete all my personal data and account records under GDPR Article 17."
CASE-102,user2@example.com,2026-10-02T11:00:00Z,COMPLETE,2026-10-03T15:00:00Z,2026-10-05T00:00:00Z,"I request permanent erasure of my profile, emails, and account data immediately."
CASE-103,user3@example.com,2026-10-04T14:00:00Z,NOT_STARTED,,2026-10-05T00:00:00Z,"What is your company privacy policy regarding data retention periods?"`,

  'user_identities.csv': `identity_id,user_id,email,email_secondary,phone,username,email_hash
1,u_101,user1@example.com,user1.alt@corp.com,+15550101,user1_dev,hash_user1
2,u_102,user2@example.com,,+15550202,user2_app,hash_user2
3,u_103,user3@example.com,,+15550303,user3_info,hash_user3`,

  'user_audit_log.csv': `audit_id,user_id,changed_at,identifier_type,old_value,new_value
101,u_101,2026-08-10T10:00:00Z,email,user1.old@domain.org,user1@example.com
102,u_102,2026-07-01T08:00:00Z,phone,+15559999,+15550202`,

  'system_activity.csv': `activity_id,system_id,kind,status,started_at,ended_at,data_categories,user_refs,evidence_id
act_sync_01,crm_sync,sync,active,2026-10-01T00:00:00Z,,crm_profile,user2@example.com,ev_act_01
act_done_01,batch_purge,delete,completed,2026-10-02T00:00:00Z,2026-10-02T01:00:00Z,auth_profile,user1@example.com,ev_act_02`,

  'deletion_rules.csv': `data_category,treatment,fields_to_remove,keep_fields,is_tombstone
auth_profile,DELETE,,,false
marketing_lead,DELETE,,,false
crm_profile,DELETE,,,false
financial_tax,RETAIN,,transaction_id,false
activity_log,REDACT,"name,email,ip_address",,false
session_log,ANONYMIZE,"user_id,email,phone",,false`,

  'evidence_files.csv': `file_id,file_path,system_id,file_type
ev_db_01,evidence/user_db_export.csv,postgres_main,csv
ev_json_01,evidence/app_events.json,events_store,json
ev_log_01,evidence/sync_worker.log,log_aggregator,log`
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'upload' | 'consensus' | 'keys'>('upload');
  const [health, setHealth] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [auditLoading, setAuditLoading] = useState<boolean>(false);
  const [consensusLoading, setConsensusLoading] = useState<boolean>(false);
  const [results, setResults] = useState<{ pipelineA: CaseResult[]; pipelineB: CaseResult[] }>({ pipelineA: [], pipelineB: [] });
  const [diffRows, setDiffRows] = useState<DiffRow[]>([]);
  const [runLogs, setRunLogs] = useState<string>('');
  const [runDir, setRunDir] = useState<string>('');
  const [selectedCaseId, setSelectedCaseId] = useState<string>('CASE-001');
  const [reviewDecisions, setReviewDecisions] = useState<Record<string, { decision: 'A' | 'B'; note: string }>>({});
  
  // Consensus State & Keys
  const [juryData, setJuryData] = useState<any>(null);
  const [selectedConsensusCase, setSelectedConsensusCase] = useState<string>('CASE-001');
  const [modelCsvs, setModelCsvs] = useState<Record<string, string>>({});
  const [consensusCsv, setConsensusCsv] = useState<string>('');
  const [consensusError, setConsensusError] = useState<string>('');
  
  // API Keys Input State
  const [keyInputs, setKeyInputs] = useState<{ deepseek: string; anthropic: string; openai: string; gemini: string }>({
    deepseek: '',
    anthropic: '',
    openai: '',
    gemini: ''
  });
  const [keySaving, setKeySaving] = useState<boolean>(false);
  const [keySaveMessage, setKeySaveMessage] = useState<string>('');

  // Datasets
  const [datasets, setDatasets] = useState<any>({ tables: {}, evidenceFiles: [] });
  const [selectedTable, setSelectedTable] = useState<string>('deletion_requests.csv');
  const [tableEditorContent, setTableEditorContent] = useState<string>('');
  const [datasetSaving, setDatasetSaving] = useState<boolean>(false);

  // Files
  const [filesList, setFilesList] = useState<FileMeta[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileMeta | null>(null);
  const [fileFilter, setFileFilter] = useState<string>('');

  // Fixes
  const [fixing, setFixing] = useState<boolean>(false);
  const [fixMessage, setFixMessage] = useState<string>('');
  const [finalizing, setFinalizing] = useState<boolean>(false);
  const [finalizedCsv, setFinalizedCsv] = useState<string>('');

  // Upload state
  const [uploadedFile, setUploadedFile] = useState<{ name: string; content: string } | null>(null);
  const [targetTable, setTargetTable] = useState<string>('auto');
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const [uploadPreview, setUploadPreview] = useState<{ headers: string[]; rows: string[][]; detected: string; rowCount: number } | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initial load
  useEffect(() => {
    fetchHealth();
    fetchDatasets();
    fetchFiles();
    fetchConsensus();
  }, []);

  const fetchHealth = async () => {
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      setHealth(data);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchDatasets = async () => {
    try {
      const res = await fetch('/api/datasets');
      const data = await res.json();
      setDatasets(data);
      if (data.tables && data.tables['deletion_requests.csv']) {
        setTableEditorContent(data.tables['deletion_requests.csv'].content || '');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchFiles = async () => {
    try {
      const res = await fetch('/api/files');
      const data = await res.json();
      setFilesList(data.files || []);
      if (data.files && data.files.length > 0) {
        setSelectedFile(data.files[0]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Fetch Consensus Matrix of real case IDs from active dataset
  const fetchConsensus = async () => {
    try {
      const res = await fetch('/api/audit/consensus');
      const data = await res.json();
      if (data.juryReport && data.juryReport.case_votes) {
        setJuryData(data.juryReport.case_votes);
        const caseIds = Object.keys(data.juryReport.case_votes);
        if (caseIds.length > 0) {
          setSelectedConsensusCase(caseIds[0]);
        }
      }
      if (data.modelCsvs) setModelCsvs(data.modelCsvs);
      if (data.consensusCsv) setConsensusCsv(data.consensusCsv);
    } catch (e) {
      console.error('Failed to fetch consensus:', e);
    }
  };

  // Rule-Based Pipeline Execution (Pipeline A ONLY)
  const handleRunRuleBased = async () => {
    setAuditLoading(true);
    setRunLogs('Executing Rule-Based Pipeline (Pipeline A - Deterministic Statutory Logic)...');
    try {
      const res = await fetch('/api/audit/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'rules' })
      });
      const data = await res.json();
      if (data.error) {
        setRunLogs(`Error: ${data.error}\n${data.stack || ''}`);
      } else {
        setRunDir(data.runDir || '');
        setRunLogs(data.runOutput || 'Rule-based execution completed.');
        if (data.results) {
          setResults({
            pipelineA: data.results.pipelineA || [],
            pipelineB: []
          });
          if (data.results.pipelineA && data.results.pipelineA.length > 0) {
            setSelectedCaseId(data.results.pipelineA[0].case_id);
          }
        }
      }
    } catch (err: any) {
      setRunLogs(`Failed to run rule-based pipeline: ${err.message}`);
    } finally {
      setAuditLoading(false);
    }
  };

  // Multi-Model AI Consensus Jury (NO SIMULATION - Live AI Models ONLY)
  const handleRunConsensus = async () => {
    setConsensusLoading(true);
    setConsensusError('');
    try {
      const res = await fetch('/api/audit/multi-model-consensus', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deepseekKey: keyInputs.deepseek,
          anthropicKey: keyInputs.anthropic,
          openaiKey: keyInputs.openai,
          geminiKey: keyInputs.gemini
        })
      });
      const data = await res.json();
      if (data.allKeysAbsent) {
        setConsensusError(data.message);
        if (data.juryReport?.case_votes) {
          setJuryData(data.juryReport.case_votes);
          const caseIds = Object.keys(data.juryReport.case_votes);
          if (caseIds.length > 0) {
            setSelectedConsensusCase(caseIds[0]);
          }
        }
        setActiveTab('consensus');
      } else if (!res.ok || data.error) {
        setConsensusError(data.message || data.error);
        setActiveTab('consensus');
      } else {
        setJuryData(data.juryReport?.case_votes || null);
        setModelCsvs(data.modelCsvs || {});
        setConsensusCsv(data.consensusCsv || '');
        const caseIds = Object.keys(data.juryReport?.case_votes || {});
        if (caseIds.length > 0) {
          setSelectedConsensusCase(caseIds[0]);
        }
        setActiveTab('consensus');
      }
    } catch (e: any) {
      setConsensusError(`Error connecting to AI Model Jury: ${e.message}`);
    } finally {
      setConsensusLoading(false);
    }
  };

  const handleSaveKeys = async () => {
    setKeySaving(true);
    setKeySaveMessage('');
    try {
      const res = await fetch('/api/keys/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deepseekKey: keyInputs.deepseek,
          anthropicKey: keyInputs.anthropic,
          openaiKey: keyInputs.openai,
          geminiKey: keyInputs.gemini
        })
      });
      const data = await res.json();
      if (data.success) {
        setKeySaveMessage('API keys updated on server! You can now run the AI Model Jury.');
        await fetchHealth();
        setConsensusError('');
      }
    } catch (e: any) {
      setKeySaveMessage(`Failed to save keys: ${e.message}`);
    } finally {
      setKeySaving(false);
    }
  };

  const handleApplyFixes = async () => {
    setFixing(true);
    try {
      const res = await fetch('/api/audit/apply-fixes', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setFixMessage('5 Critical Bug Fixes successfully applied to the Python codebase!');
        fetchFiles();
      } else {
        setFixMessage(`Fix error: ${data.error}`);
      }
    } catch (e: any) {
      setFixMessage(`Failed to apply fixes: ${e.message}`);
    } finally {
      setFixing(false);
    }
  };

  const handleSaveDataset = async () => {
    setDatasetSaving(true);
    try {
      const res = await fetch('/api/datasets/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: selectedTable, content: tableEditorContent })
      });
      const data = await res.json();
      if (data.success) {
        await fetchDatasets();
        alert(`Saved ${selectedTable}!`);
      }
    } catch (e: any) {
      alert(`Save error: ${e.message}`);
    } finally {
      setDatasetSaving(false);
    }
  };

  const handleLoadPreset = async (preset: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/datasets/preset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preset })
      });
      const data = await res.json();
      if (data.success) {
        await fetchDatasets();
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleApproveCase = async (caseId: string, decision: 'A' | 'B') => {
    const updated = {
      ...reviewDecisions,
      [caseId]: { decision, note: `User selected Pipeline ${decision} via UI review` }
    };
    setReviewDecisions(updated);

    if (runDir) {
      await fetch('/api/audit/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ runDir, decisions: updated })
      });
    }
  };

  const handleFinalize = async () => {
    setFinalizing(true);
    try {
      if (runDir) {
        await fetch('/api/audit/review', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ runDir, decisions: reviewDecisions })
        });
      }

      const res = await fetch('/api/audit/finalize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ runDir, outputPath: 'output.csv' })
      });
      const data = await res.json();
      if (data.success) {
        setFinalizedCsv(data.content || '');
        alert('Audit successfully finalized! Validated output.csv generated.');
      } else {
        alert(`Finalize error: ${data.error || data.stderr}`);
      }
    } catch (e: any) {
      alert(e.message);
    } finally {
      setFinalizing(false);
    }
  };

  // CSV File Upload handling
  const parseCsvText = (text: string) => {
    const lines = text.trim().split('\n');
    if (lines.length === 0 || !text.trim()) return { headers: [], rows: [], count: 0 };
    const parseLine = (line: string) => {
      const row: string[] = [];
      let inQuotes = false;
      let curr = '';
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') inQuotes = !inQuotes;
        else if (ch === ',' && !inQuotes) {
          row.push(curr.trim());
          curr = '';
        } else {
          curr += ch;
        }
      }
      row.push(curr.trim());
      return row;
    };
    const headers = parseLine(lines[0] || '');
    const rows = lines.slice(1).map(parseLine);
    return { headers, rows, count: Math.max(0, lines.length - 1) };
  };

  const processUploadedContent = (name: string, content: string) => {
    setUploadedFile({ name, content });
    const { headers, rows, count } = parseCsvText(content);
    
    // Detect type
    const lowerHeaders = headers.map(h => h.toLowerCase().replace(/['"]/g, ''));
    let detected = 'evidence_custom';
    if (lowerHeaders.includes('case_id') && (lowerHeaders.includes('email') || lowerHeaders.includes('requested_at'))) {
      detected = 'deletion_requests.csv';
    } else if (lowerHeaders.includes('identity_id') || (lowerHeaders.includes('user_id') && lowerHeaders.includes('email_secondary'))) {
      detected = 'user_identities.csv';
    } else if (lowerHeaders.includes('audit_id') || (lowerHeaders.includes('old_value') && lowerHeaders.includes('new_value'))) {
      detected = 'user_audit_log.csv';
    } else if (lowerHeaders.includes('activity_id') || (lowerHeaders.includes('system_id') && lowerHeaders.includes('kind'))) {
      detected = 'system_activity.csv';
    } else if (lowerHeaders.includes('data_category') && lowerHeaders.includes('treatment')) {
      detected = 'deletion_rules.csv';
    } else if (lowerHeaders.includes('file_id') && lowerHeaders.includes('file_path')) {
      detected = 'evidence_files.csv';
    }

    setUploadPreview({ headers, rows, detected, rowCount: count });
    if (targetTable === 'auto') {
      setUploadStatus(`Detected: ${detected} (${count} rows)`);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        processUploadedContent(file.name, content);
      };
      reader.readAsText(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        processUploadedContent(file.name, content);
      };
      reader.readAsText(file);
    }
  };

  const handleUploadAndRunAI = async () => {
    if (!uploadedFile) {
      alert('Please select or drop a CSV file first.');
      return;
    }
    setLoading(true);
    setUploadStatus('Saving uploaded CSV to dataset...');
    try {
      const effectiveTarget = targetTable === 'auto' ? (uploadPreview?.detected || 'deletion_requests.csv') : targetTable;
      const res = await fetch('/api/datasets/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: uploadedFile.content,
          fileName: uploadedFile.name,
          targetType: effectiveTarget
        })
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to upload CSV');
      }

      setUploadStatus(`Saved as ${data.fileName}! Executing AI Model Jury...`);
      await fetchDatasets();
      // Run AI consensus strictly (NO RULES)
      await handleRunConsensus();
    } catch (err: any) {
      setUploadStatus(`Upload error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleUploadAndRunRules = async () => {
    if (!uploadedFile) {
      alert('Please select or drop a CSV file first.');
      return;
    }
    setLoading(true);
    setUploadStatus('Saving uploaded CSV to dataset...');
    try {
      const effectiveTarget = targetTable === 'auto' ? (uploadPreview?.detected || 'deletion_requests.csv') : targetTable;
      const res = await fetch('/api/datasets/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: uploadedFile.content,
          fileName: uploadedFile.name,
          targetType: effectiveTarget
        })
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to upload CSV');
      }

      setUploadStatus(`Saved as ${data.fileName}! Executing Rule-Based Engine...`);
      await fetchDatasets();
      await handleRunRuleBased();
    } catch (err: any) {
      setUploadStatus(`Upload error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const downloadTextFile = (filename: string, content: string) => {
    if (!content) return;
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const activeCases = results.pipelineA;
  const currentCaseA = results.pipelineA.find(c => c.case_id === selectedCaseId);

  // Missing keys list
  const missingKeys: string[] = [];
  if (!health?.apiKeys?.deepseek && !keyInputs.deepseek) missingKeys.push('DeepSeek');
  if (!health?.apiKeys?.anthropic && !keyInputs.anthropic) missingKeys.push('Anthropic Claude');
  if (!health?.apiKeys?.openai && !keyInputs.openai) missingKeys.push('OpenAI');
  if (!health?.apiKeys?.gemini && !keyInputs.gemini) missingKeys.push('Google Gemini');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur px-6 py-3.5 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-indigo-500 to-sky-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white font-bold">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white">PrivacyAudit Studio</h1>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                Strict Dual Execution Mode
              </span>
            </div>
            <p className="text-xs text-slate-400">Strict AI Model Generation OR Explicit Rule-Based Pipeline</p>
          </div>
        </div>

        {/* Action Buttons: Strict Rule-Based vs AI Model Jury */}
        <div className="flex items-center gap-2.5">
          {/* Explicit Rule Based Button */}
          <button
            onClick={handleRunRuleBased}
            disabled={auditLoading}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg shadow transition active:scale-95"
            title="Runs purely deterministic rules (Pipeline A) - Zero AI models called"
          >
            {auditLoading ? <RefreshCw className="h-4 w-4 animate-spin text-amber-400" /> : <Play className="h-4 w-4 text-amber-400" />}
            <span>Run Rule-Based Pipeline</span>
          </button>

          {/* AI Model Jury Button */}
          <button
            onClick={handleRunConsensus}
            disabled={consensusLoading}
            className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-md transition active:scale-95"
            title="Runs DeepSeek, Claude, OpenAI, and Gemini models - Requires API keys"
          >
            {consensusLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Scale className="h-4 w-4" />}
            <span>Run AI Model Jury</span>
          </button>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="border-b border-slate-800 bg-slate-900/50 px-6 flex items-center gap-1 overflow-x-auto">
        <button
          onClick={() => setActiveTab('upload')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition ${
            activeTab === 'upload'
              ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <UploadCloud className="h-4 w-4 text-sky-400" />
          <span>Upload CSV & Check Output</span>
        </button>

        <button
          onClick={() => setActiveTab('consensus')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition ${
            activeTab === 'consensus'
              ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Scale className="h-4 w-4 text-amber-400" />
          <span>AI Model Jury Output</span>
          {juryData && <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">Active</span>}
        </button>

        <button
          onClick={() => setActiveTab('keys')}
          className={`flex items-center gap-2 px-4 py-3 text-xs font-semibold border-b-2 transition ${
            activeTab === 'keys'
              ? 'border-indigo-500 text-indigo-400 bg-indigo-500/5'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <KeyRound className="h-4 w-4 text-rose-400" />
          <span>API Keys Configuration</span>
          {missingKeys.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-bold">
              {missingKeys.length} Absent
            </span>
          )}
        </button>
      </nav>

      {/* Missing Keys Notice Banner */}
      {missingKeys.length > 0 && (
        <div className="bg-rose-950/40 border-b border-rose-500/30 px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-rose-300">
            <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
            <span>
              <strong>Key absent alert:</strong> The following AI keys are absent: <code className="text-rose-200 font-bold">{missingKeys.join(', ')}</code>.
              Please paste your key(s) to generate CSV with AI models. Zero simulated data will be shown.
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('keys')}
              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-bold"
            >
              Paste Keys Here
            </button>
            <button
              onClick={handleRunRuleBased}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-medium"
            >
              Or Run Rule-Based
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 p-6">
        {/* Tab: API Keys Configuration */}
        {activeTab === 'keys' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <KeyRound className="h-5 w-5 text-rose-400" />
                  Paste & Configure AI Model API Keys
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Per strict order: <strong>No simulated or fake data is generated.</strong> If keys are absent, AI models will not output data until valid keys are pasted.
                </p>
              </div>

              {keySaveMessage && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-lg flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>{keySaveMessage}</span>
                </div>
              )}

              <div className="space-y-4 pt-2">
                {/* DeepSeek */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-indigo-400 flex items-center gap-2">
                      <Bot className="h-4 w-4" /> DeepSeek API Key (DEEPSEEK_API_KEY)
                    </label>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                      health?.apiKeys?.deepseek || keyInputs.deepseek
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {health?.apiKeys?.deepseek || keyInputs.deepseek ? 'CONFIGURED' : 'KEY ABSENT'}
                    </span>
                  </div>
                  <input
                    type="password"
                    placeholder="Paste sk-... from https://api.deepseek.com"
                    value={keyInputs.deepseek}
                    onChange={(e) => setKeyInputs(prev => ({ ...prev, deepseek: e.target.value }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">Target endpoint: <code className="text-slate-400">https://api.deepseek.com</code> (model: deepseek-chat / deepseek-reasoner)</p>
                </div>

                {/* Anthropic Claude */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-amber-400 flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" /> Anthropic Claude API Key (ANTHROPIC_API_KEY)
                    </label>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                      health?.apiKeys?.anthropic || keyInputs.anthropic
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {health?.apiKeys?.anthropic || keyInputs.anthropic ? 'CONFIGURED' : 'KEY ABSENT'}
                    </span>
                  </div>
                  <input
                    type="password"
                    placeholder="Paste sk-ant-... from Anthropic Console"
                    value={keyInputs.anthropic}
                    onChange={(e) => setKeyInputs(prev => ({ ...prev, anthropic: e.target.value }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">Target model: <code className="text-slate-400">claude-3-7-sonnet-20250219</code> (Claude 3.7 Sonnet)</p>
                </div>

                {/* OpenAI */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-emerald-400 flex items-center gap-2">
                      <Sparkles className="h-4 w-4" /> OpenAI API Key (OPENAI_API_KEY)
                    </label>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                      health?.apiKeys?.openai || keyInputs.openai
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {health?.apiKeys?.openai || keyInputs.openai ? 'CONFIGURED' : 'KEY ABSENT'}
                    </span>
                  </div>
                  <input
                    type="password"
                    placeholder="Paste sk-proj-... from OpenAI Platform"
                    value={keyInputs.openai}
                    onChange={(e) => setKeyInputs(prev => ({ ...prev, openai: e.target.value }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">Target model: <code className="text-slate-400">gpt-4o</code> (OpenAI Flagship)</p>
                </div>

                {/* Gemini */}
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-sky-400 flex items-center gap-2">
                      <Cpu className="h-4 w-4" /> Google Gemini API Key (GEMINI_API_KEY)
                    </label>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                      health?.apiKeys?.gemini || keyInputs.gemini
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {health?.apiKeys?.gemini || keyInputs.gemini ? 'CONFIGURED' : 'KEY ABSENT'}
                    </span>
                  </div>
                  <input
                    type="password"
                    placeholder="Paste AIzaSy... or pre-injected in AI Studio"
                    value={keyInputs.gemini}
                    onChange={(e) => setKeyInputs(prev => ({ ...prev, gemini: e.target.value }))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">Target model: <code className="text-slate-400">gemini-3.1-flash-lite / gemini-3.8-flash</code> (Latest Active Models)</p>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-between">
                <span className="text-xs text-slate-400">Keys are kept securely in memory for the active session.</span>
                <button
                  onClick={handleSaveKeys}
                  disabled={keySaving}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-lg transition"
                >
                  {keySaving ? 'Saving Keys...' : 'Save & Apply Keys'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab: Upload CSV & Check Output */}
        {activeTab === 'upload' && (
          <div className="space-y-6 max-w-6xl mx-auto">
            <div className="bg-gradient-to-br from-slate-900 to-indigo-950/40 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2.5">
                    <UploadCloud className="h-6 w-6 text-indigo-400" />
                    Upload Your CSV File & Run Audit
                  </h2>
                  <p className="text-xs text-slate-300 mt-1">
                    Upload your CSV and choose: generate output strictly with <strong>AI Model Jury</strong> or strictly with <strong>Rule-Based Pipeline</strong>.
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400 font-medium">Sample templates:</span>
                  <button
                    onClick={() => downloadTextFile('deletion_requests.csv', TEMPLATES['deletion_requests.csv'])}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center gap-1"
                  >
                    <Download className="h-3 w-3" /> deletion_requests.csv
                  </button>
                  <button
                    onClick={() => downloadTextFile('deletion_rules.csv', TEMPLATES['deletion_rules.csv'])}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 flex items-center gap-1"
                  >
                    <Download className="h-3 w-3" /> deletion_rules.csv
                  </button>
                </div>
              </div>

              {/* Drag and Drop Zone */}
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition flex flex-col items-center justify-center gap-3 ${
                  isDragging
                    ? 'border-indigo-400 bg-indigo-500/10'
                    : 'border-slate-700 hover:border-indigo-500/60 bg-slate-950/60'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".csv,text/csv"
                  className="hidden"
                />
                <div className="h-12 w-12 rounded-full bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-inner">
                  <FileSpreadsheet className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">
                    {uploadedFile ? uploadedFile.name : 'Click to browse or drag and drop your CSV file here'}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Supports <code className="text-indigo-300">deletion_requests.csv</code>, identities, audit logs, rules, or custom evidence CSV
                  </p>
                </div>
              </div>

              {/* Strict Two-Button Action Panel */}
              <div className="mt-4 flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-800/80">
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-slate-400 font-medium">Target Destination:</span>
                  <select
                    value={targetTable}
                    onChange={(e) => setTargetTable(e.target.value)}
                    className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="auto">Auto-detect from CSV columns</option>
                    <option value="deletion_requests.csv">deletion_requests.csv (Erasure requests)</option>
                    <option value="user_identities.csv">user_identities.csv (User IDs & emails)</option>
                    <option value="user_audit_log.csv">user_audit_log.csv (Historical aliases)</option>
                    <option value="system_activity.csv">system_activity.csv (Sync & backup jobs)</option>
                    <option value="deletion_rules.csv">deletion_rules.csv (Retention & redaction rules)</option>
                    <option value="evidence_files.csv">evidence_files.csv (Evidence manifest)</option>
                    <option value="evidence_custom">evidence/*.csv (Raw evidence dataset)</option>
                  </select>

                  {uploadPreview?.detected && (
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-medium">
                      Auto-matched: {uploadPreview.detected}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2.5">
                  {/* Strict Rule-Based Button */}
                  <button
                    onClick={handleUploadAndRunRules}
                    disabled={!uploadedFile || loading || auditLoading}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-amber-300 border border-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow"
                    title="Generate CSV strictly using the deterministic rules engine"
                  >
                    <Play className="h-4 w-4 text-amber-400" />
                    <span>Generate CSV by Rules</span>
                  </button>

                  {/* Strict AI Model Button */}
                  <button
                    onClick={handleUploadAndRunAI}
                    disabled={!uploadedFile || loading || consensusLoading}
                    className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2"
                    title="Generate CSV strictly by DeepSeek + Claude + OpenAI + Gemini AI models"
                  >
                    {consensusLoading ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : (
                      <Scale className="h-4 w-4" />
                    )}
                    <span>Generate CSV by AI Models</span>
                  </button>
                </div>
              </div>

              {uploadStatus && (
                <div className="mt-3 p-3 rounded-lg bg-slate-950/80 border border-slate-800 text-xs text-slate-300 font-mono flex items-center gap-2">
                  <Info className="h-4 w-4 text-sky-400 shrink-0" />
                  <span>{uploadStatus}</span>
                </div>
              )}
            </div>

            {/* Uploaded CSV Preview Table */}
            {uploadPreview && (
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
                <div className="p-3.5 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-emerald-400" />
                    <span className="text-xs font-bold text-white">Uploaded CSV Full Dataset</span>
                    <span className="text-[11px] text-slate-400 font-mono">({uploadPreview.rowCount} rows total)</span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-mono font-semibold">Showing all {uploadPreview.rowCount} rows</span>
                </div>

                <div className="overflow-x-auto max-h-[480px] overflow-y-auto">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-950 text-slate-300 border-b border-slate-800 sticky top-0 z-10 shadow-sm">
                      <tr>
                        <th className="py-2.5 px-3 font-semibold text-slate-400 text-center w-12 bg-slate-950">#</th>
                        {uploadPreview.headers.map((h, i) => (
                          <th key={i} className="py-2.5 px-3 font-semibold text-indigo-300 bg-slate-950">
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 text-slate-300">
                      {uploadPreview.rows.map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-slate-800/30">
                          <td className="py-2 px-3 text-slate-500 font-mono text-center text-[10px] bg-slate-950/40">
                            {rIdx + 1}
                          </td>
                          {row.map((cell, cIdx) => (
                            <td key={cIdx} className="py-2 px-3 whitespace-nowrap">
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab: AI Model Jury Output */}
        {activeTab === 'consensus' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Scale className="h-6 w-6 text-amber-400" />
                  <h2 className="text-xl font-bold text-white">Multi-Model AI Jury (Strict No-Simulation)</h2>
                </div>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  Evaluated strictly by <strong>DeepSeek</strong>, <strong>Anthropic Claude</strong>, <strong>OpenAI GPT-4o</strong>, and <strong>Google Gemini</strong>. 
                  Models without keys are flagged as <code className="text-rose-300">KEY_ABSENT</code>.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleRunConsensus}
                  disabled={consensusLoading}
                  className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-lg flex items-center gap-2"
                >
                  {consensusLoading ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4 fill-white" />}
                  <span>{consensusLoading ? 'Jury Adjudicating...' : 'Re-Run AI Model Jury'}</span>
                </button>
              </div>
            </div>

            {/* Error / Key Absent Message */}
            {consensusError && (
              <div className="p-4 bg-rose-950/40 border border-rose-500/40 rounded-xl text-xs space-y-2">
                <div className="flex items-center gap-2 font-bold text-rose-300">
                  <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />
                  <span>Cannot execute AI Model Generation: Key is absent!</span>
                </div>
                <p className="text-slate-300">
                  {consensusError}
                </p>
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('keys')}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-lg text-xs"
                  >
                    Paste API Key(s) Now
                  </button>
                  <button
                    onClick={handleRunRuleBased}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs"
                  >
                    Run Rule-Based Pipeline Instead
                  </button>
                </div>
              </div>
            )}

            {/* Model Architecture Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* DeepSeek */}
              <div className="bg-slate-900/80 border border-indigo-500/30 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-400 flex items-center gap-1.5">
                    <Bot className="h-4 w-4" /> DeepSeek
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                    health?.apiKeys?.deepseek || keyInputs.deepseek ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {health?.apiKeys?.deepseek || keyInputs.deepseek ? 'LIVE' : 'KEY ABSENT'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Deep reasoning effort on graph identifiers and residual unpurged records.
                </p>
                {modelCsvs['deepseek'] && (
                  <button
                    onClick={() => downloadTextFile('output_deepseek.csv', modelCsvs['deepseek'])}
                    className="text-[11px] text-indigo-400 hover:underline flex items-center gap-1 pt-1"
                  >
                    <Download className="h-3 w-3" /> Download output_deepseek.csv
                  </button>
                )}
              </div>

              {/* Anthropic Claude */}
              <div className="bg-slate-900/80 border border-amber-500/30 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <ShieldCheck className="h-4 w-4" /> Claude 3.7 Sonnet
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                    health?.apiKeys?.anthropic || keyInputs.anthropic ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {health?.apiKeys?.anthropic || keyInputs.anthropic ? 'LIVE' : 'KEY ABSENT'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Legal statutory nuances: GDPR Art. 17 exceptions & tax retention.
                </p>
                {modelCsvs['anthropic'] && (
                  <button
                    onClick={() => downloadTextFile('output_anthropic.csv', modelCsvs['anthropic'])}
                    className="text-[11px] text-amber-400 hover:underline flex items-center gap-1 pt-1"
                  >
                    <Download className="h-3 w-3" /> Download output_anthropic.csv
                  </button>
                )}
              </div>

              {/* OpenAI GPT-4o */}
              <div className="bg-slate-900/80 border border-emerald-500/30 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4" /> OpenAI GPT-4o
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                    health?.apiKeys?.openai || keyInputs.openai ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {health?.apiKeys?.openai || keyInputs.openai ? 'LIVE' : 'KEY ABSENT'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Step ordering verification & cross-model consensus synthesis.
                </p>
                {modelCsvs['openai'] && (
                  <button
                    onClick={() => downloadTextFile('output_openai.csv', modelCsvs['openai'])}
                    className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1 pt-1"
                  >
                    <Download className="h-3 w-3" /> Download output_openai.csv
                  </button>
                )}
              </div>

              {/* Google Gemini */}
              <div className="bg-slate-900/80 border border-sky-500/30 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
                    <Cpu className="h-4 w-4" /> Gemini Flash (Latest)
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold ${
                    health?.apiKeys?.gemini || keyInputs.gemini ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                  }`}>
                    {health?.apiKeys?.gemini || keyInputs.gemini ? 'LIVE' : 'KEY ABSENT'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  High-speed multimodal evidence cross-referencing with active Gemini models.
                </p>
                {modelCsvs['gemini'] && (
                  <button
                    onClick={() => downloadTextFile('output_gemini.csv', modelCsvs['gemini'])}
                    className="text-[11px] text-sky-400 hover:underline flex items-center gap-1 pt-1"
                  >
                    <Download className="h-3 w-3" /> Download output_gemini.csv
                  </button>
                )}
              </div>
            </div>

            {/* Consensus Matrix Table */}
            {juryData && (
              <div className="space-y-4">
                <div className="bg-slate-900/70 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
                  <div className="p-4 border-b border-slate-800 bg-slate-900 flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Split className="h-4 w-4 text-indigo-400" />
                        <h3 className="text-sm font-bold text-white">
                          Live AI Model Votes & Supreme Consensus Output
                        </h3>
                        <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-mono text-[11px] font-bold border border-indigo-500/30">
                          Showing all {Object.keys(juryData).length} Real Cases
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        Displaying 100% real Case IDs loaded from active dataset. Strict zero-simulation policy.
                      </p>
                    </div>

                    {consensusCsv && (
                      <button
                        onClick={() => downloadTextFile('output_consensus.csv', consensusCsv)}
                        className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow"
                      >
                        <Download className="h-3.5 w-3.5" /> Download output_consensus.csv
                      </button>
                    )}
                  </div>

                  <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
                    <table className="w-full text-left text-xs font-mono">
                      <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0 z-10 shadow-sm">
                        <tr>
                          <th className="py-2.5 px-3 font-semibold text-slate-400 text-center w-12 bg-slate-950">#</th>
                          <th className="py-2.5 px-4 font-semibold text-slate-200 bg-slate-950">Real Case ID</th>
                          <th className="py-2.5 px-3 font-semibold text-indigo-300 bg-slate-950">DeepSeek</th>
                          <th className="py-2.5 px-3 font-semibold text-amber-300 bg-slate-950">Claude</th>
                          <th className="py-2.5 px-3 font-semibold text-emerald-300 bg-slate-950">OpenAI</th>
                          <th className="py-2.5 px-3 font-semibold text-sky-300 bg-slate-950">Gemini</th>
                          <th className="py-2.5 px-3 font-semibold text-slate-300 bg-slate-950">Agreement</th>
                          <th className="py-2.5 px-4 font-semibold text-white bg-slate-950">Supreme Decision</th>
                          <th className="py-2.5 px-3 font-semibold bg-slate-950">Steps</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/80 text-slate-200">
                        {Object.entries(juryData).map(([cid, data]: [string, any], idx: number) => {
                          const isSelected = cid === selectedConsensusCase;
                          const agreement = Math.round(data.agreement_pct || 0);

                          return (
                            <tr
                              key={cid}
                              onClick={() => setSelectedConsensusCase(cid)}
                              className={`cursor-pointer transition ${
                                isSelected ? 'bg-indigo-950/60 border-l-4 border-indigo-500 text-white' : 'hover:bg-slate-800/40'
                              }`}
                            >
                              <td className="py-3 px-3 text-slate-500 font-mono text-center text-[11px] bg-slate-950/30">
                                {idx + 1}
                              </td>
                              <td className="py-3 px-4 font-bold text-white flex items-center gap-1.5">
                                <span className="font-mono text-indigo-300">{cid}</span>
                                {isSelected && <span className="text-[10px] text-indigo-400">●</span>}
                              </td>
                              <td className="py-3 px-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  data.votes.deepseek?.status === 'KEY_ABSENT'
                                    ? 'bg-rose-500/10 text-rose-400'
                                    : data.votes.deepseek?.status === 'COMPLETE'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : data.votes.deepseek?.status === 'READY'
                                    ? 'bg-sky-500/10 text-sky-400'
                                    : 'bg-amber-500/10 text-amber-400'
                                }`}>
                                  {data.votes.deepseek?.status}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  data.votes.anthropic?.status === 'KEY_ABSENT'
                                    ? 'bg-rose-500/10 text-rose-400'
                                    : data.votes.anthropic?.status === 'COMPLETE'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : data.votes.anthropic?.status === 'READY'
                                    ? 'bg-sky-500/10 text-sky-400'
                                    : 'bg-amber-500/10 text-amber-400'
                                }`}>
                                  {data.votes.anthropic?.status}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  data.votes.openai?.status === 'KEY_ABSENT'
                                    ? 'bg-rose-500/10 text-rose-400'
                                    : data.votes.openai?.status === 'COMPLETE'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : data.votes.openai?.status === 'READY'
                                    ? 'bg-sky-500/10 text-sky-400'
                                    : 'bg-amber-500/10 text-amber-400'
                                }`}>
                                  {data.votes.openai?.status}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  data.votes.gemini?.status === 'KEY_ABSENT'
                                    ? 'bg-rose-500/10 text-rose-400'
                                    : data.votes.gemini?.status === 'COMPLETE'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : data.votes.gemini?.status === 'READY'
                                    ? 'bg-sky-500/10 text-sky-400'
                                    : 'bg-amber-500/10 text-amber-400'
                                }`}>
                                  {data.votes.gemini?.status}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-bold text-slate-300">
                                  {agreement}%
                                </span>
                              </td>
                              <td className="py-3 px-4">
                                <span className={`px-2.5 py-1 rounded text-xs font-bold ${
                                  data.supreme_status === 'COMPLETE'
                                    ? 'bg-emerald-500/20 text-emerald-400'
                                    : data.supreme_status === 'INCOMPLETE'
                                    ? 'bg-amber-500/20 text-amber-400'
                                    : 'bg-slate-800 text-slate-400'
                                }`}>
                                  {data.supreme_status}
                                </span>
                              </td>
                              <td className="py-3 px-3 text-slate-400">{data.step_count} ops</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Selected Case Inspection Drawer */}
                {selectedConsensusCase && juryData[selectedConsensusCase] && (
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 shadow-xl">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-3">
                        <span className="text-xs uppercase tracking-wider text-slate-400">Detailed Case Inspection:</span>
                        <span className="font-mono text-base font-bold text-indigo-300">{selectedConsensusCase}</span>
                        <span className={`px-2.5 py-0.5 rounded text-xs font-bold ${
                          juryData[selectedConsensusCase].supreme_status === 'COMPLETE'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : juryData[selectedConsensusCase].supreme_status === 'INCOMPLETE'
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-slate-800 text-slate-400'
                        }`}>
                          Supreme: {juryData[selectedConsensusCase].supreme_status}
                        </span>
                      </div>
                      <span className="text-xs text-slate-400 font-mono">
                        Consensus Agreement: {Math.round(juryData[selectedConsensusCase].agreement_pct || 0)}%
                      </span>
                    </div>

                    {/* 4 Models Reasoning Breakdown */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                      {/* DeepSeek */}
                      <div className="bg-slate-950/60 border border-indigo-500/20 rounded-lg p-3 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-indigo-400">DeepSeek</span>
                          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-300">
                            {juryData[selectedConsensusCase].votes?.deepseek?.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {juryData[selectedConsensusCase].votes?.deepseek?.reasoning || 'No evaluation notes.'}
                        </p>
                      </div>

                      {/* Anthropic Claude */}
                      <div className="bg-slate-950/60 border border-amber-500/20 rounded-lg p-3 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-400">Claude 3.5 Sonnet</span>
                          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-300">
                            {juryData[selectedConsensusCase].votes?.anthropic?.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {juryData[selectedConsensusCase].votes?.anthropic?.reasoning || 'No evaluation notes.'}
                        </p>
                      </div>

                      {/* OpenAI GPT-4o */}
                      <div className="bg-slate-950/60 border border-emerald-500/20 rounded-lg p-3 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-emerald-400">OpenAI GPT-4o</span>
                          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300">
                            {juryData[selectedConsensusCase].votes?.openai?.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {juryData[selectedConsensusCase].votes?.openai?.reasoning || 'No evaluation notes.'}
                        </p>
                      </div>

                      {/* Gemini 2.5 Flash */}
                      <div className="bg-slate-950/60 border border-sky-500/20 rounded-lg p-3 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-sky-400">Gemini 2.5 Flash</span>
                          <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-300">
                            {juryData[selectedConsensusCase].votes?.gemini?.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {juryData[selectedConsensusCase].votes?.gemini?.reasoning || 'No evaluation notes.'}
                        </p>
                      </div>
                    </div>

                    {/* Supreme Rationale */}
                    <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg text-xs space-y-1">
                      <span className="font-bold text-slate-300">Supreme Consensus Rationale:</span>
                      <p className="text-slate-400">
                        {juryData[selectedConsensusCase].supreme_rationale || 'Awaiting live model evaluation.'}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
