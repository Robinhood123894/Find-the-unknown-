from __future__ import annotations
from audit.io.schemas import Finding, Step, Record, Rule
from audit.validate.ordering import sort_steps

FINDING_OP = {
    "REMAINING": ("REPORT_REMAINING_RECORD", "PRESENT"),
    "EXPOSED_PII": ("REPORT_EXPOSED_PII", "PRESENT"),
    "FLOW": ("REPORT_ACTIVE_DATA_FLOW", "ACTIVE"),
    "RESTORE": ("REPORT_RESTORE_RISK", "ACTIVE"),
}

REMEDIATION_OP = {
    "REMAINING": ("DELETE_RECORD", "ABSENT"),
    "EXPOSED_PII_REDACT": ("REDACT_RECORD", "REDACTED"),
    "EXPOSED_PII_ANONYMIZE": ("ANONYMIZE_RECORD", "ANONYMIZED"),
    "FLOW": ("DISABLE_DATA_FLOW", "DISABLED"),
    "RESTORE": ("BLOCK_RESTORE", "BLOCKED"),
}

VERIFICATION_OP = {
    "REMAINING": ("VERIFY_RECORD_ABSENT", "ABSENT"),
    "EXPOSED_PII_REDACT": ("VERIFY_RECORD_REDACTED", "REDACTED"),
    "EXPOSED_PII_ANONYMIZE": ("VERIFY_RECORD_ANONYMIZED", "ANONYMIZED"),
    "FLOW": ("VERIFY_DATA_FLOW_DISABLED", "DISABLED"),
    "RESTORE": ("VERIFY_RESTORE_BLOCKED", "BLOCKED"),
    "RETAINED": ("VERIFY_RECORD_PRESENT", "PRESENT"),
}


def _finding_step(f: Finding) -> Step:
    op, state = FINDING_OP[f.kind]
    return Step(step_no=0, phase="FINDING",
                system_id=f.system_id, resource_id=f.resource_id,
                operation=op, state=state, evidence_id=f.evidence_id or "")


def _remediation_step(f: Finding, rule: Rule | None) -> Step:
    key = f.kind
    if f.kind == "EXPOSED_PII":
        if rule is not None and rule.treatment == "ANONYMIZE":
            key = "EXPOSED_PII_ANONYMIZE"
        else:
            key = "EXPOSED_PII_REDACT"
    op, state = REMEDIATION_OP[key]
    return Step(step_no=0, phase="REMEDIATION",
                system_id=f.system_id, resource_id=f.resource_id,
                operation=op, state=state, evidence_id="")


def _verification_step_for_finding(f: Finding, rule: Rule | None) -> Step:
    key = f.kind
    if f.kind == "EXPOSED_PII":
        if rule is not None and rule.treatment == "ANONYMIZE":
            key = "EXPOSED_PII_ANONYMIZE"
        else:
            key = "EXPOSED_PII_REDACT"
    op, state = VERIFICATION_OP[key]
    return Step(step_no=0, phase="VERIFICATION",
                system_id=f.system_id, resource_id=f.resource_id,
                operation=op, state=state, evidence_id="")


def _retained_verification(record: Record) -> Step:
    op, state = VERIFICATION_OP["RETAINED"]
    return Step(step_no=0, phase="VERIFICATION",
                system_id=record.system_id, resource_id=record.resource_id,
                operation=op, state=state,
                evidence_id=record.source_evidence_id or "")


def build_steps_incomplete(findings: list[Finding],
                           rules_by_cat: dict[str, Rule],
                           retained_records: list[Record]) -> list[Step]:
    steps: list[Step] = []
    for f in findings:
        steps.append(_finding_step(f))
    for f in findings:
        rule = rules_by_cat.get(f.data_category) if f.data_category else None
        steps.append(_remediation_step(f, rule))
    for f in findings:
        rule = rules_by_cat.get(f.data_category) if f.data_category else None
        steps.append(_verification_step_for_finding(f, rule))
    for r in retained_records:
        steps.append(_retained_verification(r))
    steps = sort_steps(steps)
    for i, s in enumerate(steps, 1):
        s.step_no = i
    return steps


def build_steps_complete(retained_records: list[Record],
                         clean_records: list[Record],
                         rules_by_cat: dict[str, Rule]) -> list[Step]:
    steps: list[Step] = []
    for r in retained_records:
        steps.append(_retained_verification(r))
    for r in clean_records:
        rule = rules_by_cat.get(r.data_category)
        if rule is None:
            continue
        ev = r.source_evidence_id or ""
        if rule.treatment == "REDACT":
            steps.append(Step(step_no=0, phase="VERIFICATION",
                              system_id=r.system_id, resource_id=r.resource_id,
                              operation="VERIFY_RECORD_REDACTED", state="REDACTED",
                              evidence_id=ev))
        elif rule.treatment == "ANONYMIZE":
            steps.append(Step(step_no=0, phase="VERIFICATION",
                              system_id=r.system_id, resource_id=r.resource_id,
                              operation="VERIFY_RECORD_ANONYMIZED", state="ANONYMIZED",
                              evidence_id=ev))
        elif rule.treatment == "DELETE":
            steps.append(Step(step_no=0, phase="VERIFICATION",
                              system_id=r.system_id, resource_id=r.resource_id,
                              operation="VERIFY_RECORD_ABSENT", state="ABSENT",
                              evidence_id=ev))
    steps = sort_steps(steps)
    for i, s in enumerate(steps, 1):
        s.step_no = i
    return steps