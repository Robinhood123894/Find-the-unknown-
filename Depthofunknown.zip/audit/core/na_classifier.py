from __future__ import annotations
import re
from audit.io.schemas import Case

DELETION_KW = re.compile(
    r"\b(delete|deletion|erase|erasure|remove|purge|forget|right to be forgotten|opt[- ]?out|close (?:my )?account|gdpr|ccpa)\b",
    re.IGNORECASE,
)
QUESTION_KW = re.compile(r"\b(how|what|where|why|can you explain|tell me about|policy|policies)\b", re.IGNORECASE)


def rule_based(case: Case) -> tuple[bool, float]:
    text = (case.request_text or "").strip()
    if not text:
        # fall back to reported_status semantics
        if case.reported_status in ("COMPLETE", "PARTIALLY_COMPLETE", "NOT_STARTED"):
            return True, 0.5
        return False, 0.4
    has_del = bool(DELETION_KW.search(text))
    has_q = bool(QUESTION_KW.search(text))
    if has_del and not has_q:
        return True, 0.95
    if has_del and has_q:
        return True, 0.6
    return False, 0.7


def is_deletion_request(case: Case, client, model: str) -> tuple[bool, str]:
    verdict, conf = rule_based(case)
    if conf >= 0.9:
        return verdict, "rule"
    ai = client.classify_na(case.request_text, case.reported_status, model)
    if ai:
        return True, "ai"
    return verdict, "rule_fallback"