from __future__ import annotations
from audit.io.schemas import Case, IdentityCluster, Record

EMAIL_FIELDS = ("email",)
PHONE_FIELDS = ("phone",)
HASH_FIELDS = ("email_hash",)
UID_FIELDS = ("user_id",)


def _norm(v: str) -> str:
    return (v or "").strip().lower()


def build_cluster(case: Case, identities: list[dict], audit_log: list[dict], records: list[Record]) -> IdentityCluster:
    ids: set[str] = set()
    sources: list[str] = []
    primary_uid = None

    if case.email:
        ids.add(_norm(case.email))

    # identities
    for row in identities:
        emails = [_norm(row.get(k, "")) for k in ("email", "email_secondary", "old_email")]
        phones = [_norm(row.get(k, "")) for k in ("phone", "phone_secondary", "old_phone")]
        hashes = [_norm(row.get(k, "")) for k in ("email_hash", "hash")]
        uid = _norm(row.get("user_id", ""))
        hit = any(e and e in ids for e in emails)
        if hit or (uid and any(e and e in ids for e in emails)):
            for e in emails:
                if e: ids.add(e)
            for p in phones:
                if p: ids.add(p)
            for h in hashes:
                if h: ids.add(h)
            if uid:
                ids.add(uid)
                primary_uid = primary_uid or uid
                if row.get("identity_id"):
                    sources.append(str(row["identity_id"]))

    # audit log fixpoint
    changed = True
    while changed:
        changed = False
        for edge in audit_log:
            old = _norm(edge.get("old_value", ""))
            new = _norm(edge.get("new_value", ""))
            uid = _norm(edge.get("user_id", ""))
            if not (old or new or uid):
                continue
            if (old and old in ids) or (new and new in ids) or (uid and uid in ids):
                for v in (old, new, uid):
                    if v and v not in ids:
                        ids.add(v); changed = True
                if edge.get("audit_id"):
                    sources.append(str(edge["audit_id"]))
                if uid:
                    primary_uid = primary_uid or uid

    # tombstones / record user_ids
    for r in records:
        for fld in UID_FIELDS:
            v = _norm(r.fields.get(fld, "") or "")
            if v and (v in ids or any(x in ids for x in _record_email_ids(r))):
                if v not in ids:
                    ids.add(v); changed = True
                primary_uid = primary_uid or v

    return IdentityCluster(
        case_id=case.case_id, identifiers=ids,
        primary_user_id=primary_uid, sources=sorted(set(sources)),
    )


def _record_email_ids(r: Record) -> set[str]:
    out = set()
    for fld in ("email", "email_hash", "phone"):
        v = _norm(r.fields.get(fld, "") or "")
        if v:
            out.add(v)
    return out


def record_matches_cluster(record: Record, cluster: IdentityCluster) -> bool:
    for fld in ("email", "email_hash", "phone", "user_id", "username"):
        v = _norm(record.fields.get(fld, "") or "")
        if v and v in cluster.identifiers:
            return True
    return False