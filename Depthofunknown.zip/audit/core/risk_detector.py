from __future__ import annotations
from datetime import datetime
from audit.io.schemas import Activity, Finding, IdentityCluster
from audit.core.timeline import activity_active_at, activity_touches_cluster


def detect_flows(activities: list[Activity], cluster: IdentityCluster, audit_at: datetime) -> list[Finding]:
    out = []
    for a in activities:
        if a.kind not in ("sync", "import", "export", "index"):
            continue
        if not activity_active_at(a, audit_at):
            continue
        if not activity_touches_cluster(a, cluster.identifiers):
            continue
        out.append(Finding(
            kind="FLOW", system_id=a.system_id, resource_id=a.activity_id,
            evidence_id=a.evidence_id or a.activity_id, activity_id=a.activity_id,
        ))
    return out


def detect_restore_risks(activities: list[Activity], cluster: IdentityCluster, audit_at: datetime) -> list[Finding]:
    out = []
    for a in activities:
        if a.kind not in ("backup", "restore"):
            continue
        if not activity_active_at(a, audit_at):
            continue
        if not activity_touches_cluster(a, cluster.identifiers):
            continue
        out.append(Finding(
            kind="RESTORE", system_id=a.system_id, resource_id=a.activity_id,
            evidence_id=a.evidence_id or a.activity_id, activity_id=a.activity_id,
        ))
    return out