from __future__ import annotations
from audit.io.schemas import Finding

def decide(is_deletion: bool, findings: list[Finding], retained_ok: bool) -> str:
    if not is_deletion:
        return "NOT_APPLICABLE"
    if findings:
        return "INCOMPLETE"
    if retained_ok:
        return "COMPLETE"
    return "INCOMPLETE"