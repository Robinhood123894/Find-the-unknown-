from __future__ import annotations
from audit.io.schemas import Record, Rule, Finding, IdentityCluster

DIRECT_ID_FIELDS = ("name", "email", "phone", "email_hash",
                    "first_name", "last_name", "username", "address")


def _has_direct_ids(record: Record, fields_to_remove: list[str]) -> bool:
    check = fields_to_remove or list(DIRECT_ID_FIELDS)
    for f in check:
        v = record.fields.get(f)
        if v not in (None, "", "none"):
            return True
    return False


def classify_record(record: Record, state: str, rule: Rule, cluster: IdentityCluster) -> Finding | None:
    if state == "ABSENT":
        return None

    if rule is None:
        rule = Rule(data_category=record.data_category, treatment="RETAIN")

    if rule.treatment == "RETAIN":
        return None

    if rule.treatment == "DELETE":
        return Finding(
            kind="REMAINING",
            system_id=record.system_id,
            resource_id=record.resource_id,
            evidence_id=record.source_evidence_id,
            data_category=record.data_category,
        )

    # REDACT or ANONYMIZE
    if rule.is_tombstone or "user_id" in rule.keep_fields:
        if _has_direct_ids(record, rule.fields_to_remove):
            return Finding(
                kind="EXPOSED_PII",
                system_id=record.system_id,
                resource_id=record.resource_id,
                evidence_id=record.source_evidence_id,
                data_category=record.data_category,
            )
        return None

    if rule.treatment == "REDACT":
        if state == "PRESENT_REDACTED":
            return None
        if _has_direct_ids(record, rule.fields_to_remove):
            return Finding(kind="EXPOSED_PII", system_id=record.system_id,
                           resource_id=record.resource_id,
                           evidence_id=record.source_evidence_id,
                           data_category=record.data_category)
        return None

    if rule.treatment == "ANONYMIZE":
        if state == "PRESENT_ANONYMIZED":
            return None
        if any((record.fields.get(f) or "") in cluster.identifiers
               for f in ("email", "email_hash", "phone", "user_id")):
            return Finding(kind="EXPOSED_PII", system_id=record.system_id,
                           resource_id=record.resource_id,
                           evidence_id=record.source_evidence_id,
                           data_category=record.data_category)
        return None

    return None