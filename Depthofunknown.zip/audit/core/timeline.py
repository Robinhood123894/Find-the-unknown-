from __future__ import annotations
from datetime import datetime, timezone
from audit.io.schemas import Record, Activity

def _utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

def state_at(record: Record, audit_at: datetime) -> str:
    audit_at_utc = _utc(audit_at)
    events = sorted([e for e in record.state_events if _utc(e.ts) <= audit_at_utc], key=lambda e: _utc(e.ts))
    if not events:
        return "PRESENT" if record.fields else "ABSENT"
    state = "PRESENT"
    for e in events:
        if e.event == "DELETE":
            state = "ABSENT"
        elif e.event in ("RESTORE", "SYNC_WRITE", "CREATE", "INDEX", "EXPORT"):
            state = "PRESENT"
        elif e.event == "REDACT":
            state = "PRESENT_REDACTED"
        elif e.event == "ANONYMIZE":
            state = "PRESENT_ANONYMIZED"
    return state


def activity_active_at(activity: Activity, audit_at: datetime) -> bool:
    audit_at_utc = _utc(audit_at)
    start_utc = _utc(activity.started_at)
    if start_utc > audit_at_utc:
        return False
    if activity.ended_at is not None and _utc(activity.ended_at) <= audit_at_utc:
        return False
    return activity.status in ("active", "completed") and activity.ended_at is None


def activity_touches_cluster(activity: Activity, cluster_identifiers: set[str]) -> bool:
    refs = set(x.lower() for x in activity.scope.get("user_refs", []))
    return bool(refs & cluster_identifiers)