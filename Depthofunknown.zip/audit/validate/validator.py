from __future__ import annotations
import json
from audit.io.schemas import Step
from audit.validate.ordering import OP_STATE, assert_sorted

FINDING_OPS = {"REPORT_REMAINING_RECORD", "REPORT_EXPOSED_PII",
               "REPORT_ACTIVE_DATA_FLOW", "REPORT_RESTORE_RISK"}
REMEDIATION_OPS = {"DISABLE_DATA_FLOW", "BLOCK_RESTORE", "DELETE_RECORD",
                   "REDACT_RECORD", "ANONYMIZE_RECORD"}
VERIFICATION_OPS = {"VERIFY_RECORD_ABSENT", "VERIFY_RECORD_PRESENT",
                    "VERIFY_RECORD_REDACTED", "VERIFY_RECORD_ANONYMIZED",
                    "VERIFY_DATA_FLOW_DISABLED", "VERIFY_RESTORE_BLOCKED"}


def validate_case(case_id: str, status: str, steps: list[Step]) -> list[str]:
    errs: list[str] = []
    if status == "NOT_APPLICABLE":
        if steps:
            errs.append(f"{case_id}: NOT_APPLICABLE must have empty steps")
        return errs
    if status == "COMPLETE":
        for s in steps:
            if s.phase != "VERIFICATION":
                errs.append(f"{case_id}: COMPLETE has non-verification step {s.operation}")
            if not s.evidence_id:
                errs.append(f"{case_id}: COMPLETE verification missing evidence_id ({s.system_id}/{s.resource_id})")
    if status == "INCOMPLETE":
        if not any(s.phase == "FINDING" for s in steps):
            errs.append(f"{case_id}: INCOMPLETE has no FINDING")
        for s in steps:
            if s.phase == "FINDING" and not s.evidence_id:
                errs.append(f"{case_id}: FINDING missing evidence_id ({s.system_id}/{s.resource_id})")
            if s.phase in ("REMEDIATION", "VERIFICATION") and s.evidence_id:
                errs.append(f"{case_id}: {s.phase} for INCOMPLETE must have empty evidence_id")
    for i, s in enumerate(steps, 1):
        if s.step_no != i:
            errs.append(f"{case_id}: step_no expected {i} got {s.step_no}")
        if s.phase == "FINDING" and s.operation not in FINDING_OPS:
            errs.append(f"{case_id}: bad FINDING op {s.operation}")
        if s.phase == "REMEDIATION" and s.operation not in REMEDIATION_OPS:
            errs.append(f"{case_id}: bad REMEDIATION op {s.operation}")
        if s.phase == "VERIFICATION" and s.operation not in VERIFICATION_OPS:
            errs.append(f"{case_id}: bad VERIFICATION op {s.operation}")
        if OP_STATE.get(s.operation) != s.state:
            errs.append(f"{case_id}: op/state mismatch {s.operation}/{s.state}")
    try:
        assert_sorted(steps)
    except AssertionError as e:
        errs.append(f"{case_id}: {e}")
    return errs


def validate_output(rows: dict[str, tuple[str, list[Step]]], expected_ids: list[str]) -> list[str]:
    errs: list[str] = []
    if set(rows.keys()) != set(expected_ids):
        missing = set(expected_ids) - set(rows.keys())
        extra = set(rows.keys()) - set(expected_ids)
        if missing: errs.append(f"missing case_ids: {sorted(missing)[:5]}...")
        if extra: errs.append(f"extra case_ids: {sorted(extra)[:5]}...")
    for cid, (status, steps) in rows.items():
        errs.extend(validate_case(cid, status, steps))
    return errs