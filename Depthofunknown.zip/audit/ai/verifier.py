from __future__ import annotations
from audit.io.schemas import (
    Case, Finding, Record, Activity, Rule, IdentityCluster
)
from audit.core.policy import classify_record
from audit.core.risk_detector import detect_flows, detect_restore_risks
from audit.core.timeline import state_at


def _bundle(case, cluster, records, activities, findings, retained):
    return {
        "case_id": case.case_id,
        "audit_at": case.audit_at.isoformat(),
        "identifiers": sorted(list(cluster.identifiers))[:50],
        "records": [
            {
                "system_id": r.system_id, "resource_id": r.resource_id,
                "data_category": r.data_category,
                "state": state_at(r, case.audit_at),
                "fields_present": [k for k, v in r.fields.items() if v],
            }
            for r in records[:200]
        ],
        "activities": [
            {"activity_id": a.activity_id, "system_id": a.system_id,
             "kind": a.kind, "status": a.status}
            for a in activities[:100]
        ],
        "current_findings": [
            {"kind": f.kind, "system_id": f.system_id, "resource_id": f.resource_id}
            for f in findings
        ],
        "retained_count": len(retained),
    }


def verify_and_refine(case, cluster, records, activities, findings, retained, clean,
                      rules_by_cat, client, model, max_retries):
    existing_keys = {(f.kind, f.system_id, f.resource_id) for f in findings}
    report = {"iterations": 0, "added": 0, "invalid_dropped": 0}

    for it in range(max_retries):
        report["iterations"] = it + 1
        bundle = _bundle(case, cluster, records, activities, findings, retained)
        resp = client.verify_case(bundle, model)
        missed = resp.get("missed", []) or []
        invalid = resp.get("invalid", []) or []

        added = 0
        if missed:
            by_key = {(r.system_id, r.resource_id): r for r in records}
            for m in missed:
                sys_id = str(m.get("system_id", ""))
                rid = str(m.get("resource_id", ""))
                kind = str(m.get("kind", "REMAINING")).upper()
                if not sys_id or not rid:
                    continue
                r = by_key.get((sys_id, rid))
                if r is None:
                    continue
                st = state_at(r, case.audit_at)
                rule = rules_by_cat.get(r.data_category)
                f = classify_record(r, st, rule, cluster)
                if f and (f.kind, f.system_id, f.resource_id) not in existing_keys:
                    findings.append(f)
                    existing_keys.add((f.kind, f.system_id, f.resource_id))
                    added += 1
            # re-run flow/restore detectors to catch newly flagged activities
            for f in detect_flows(activities, cluster, case.audit_at) + detect_restore_risks(activities, cluster, case.audit_at):
                if (f.kind, f.system_id, f.resource_id) not in existing_keys:
                    findings.append(f); existing_keys.add((f.kind, f.system_id, f.resource_id))
                    added += 1

        if invalid:
            drop_keys = {(str(i.get("system_id", "")), str(i.get("resource_id", ""))) for i in invalid}
            before = len(findings)
            findings = [f for f in findings if (f.system_id, f.resource_id) not in drop_keys]
            report["invalid_dropped"] += before - len(findings)
            existing_keys = {(f.kind, f.system_id, f.resource_id) for f in findings}

        report["added"] += added
        if added == 0 and not invalid:
            break

    return findings, retained, clean, report