from __future__ import annotations
import os, json, requests
from typing import Protocol, Optional
from pydantic import BaseModel
from audit.ai.usage import log_call

class LLMClient(Protocol):
    def is_available(self) -> bool: ...
    def verify_case(self, bundle: dict, model: str = "") -> dict: ...
    def classify_na(self, request_text: str, reported_status: str, model: str = "") -> bool: ...


class OpenAIClient:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._client = None
        if self.api_key and self.api_key.strip():
            try:
                from openai import OpenAI
                self._client = OpenAI(api_key=self.api_key.strip())
            except Exception:
                self._client = None

    def is_available(self) -> bool:
        return self._client is not None

    def verify_case(self, bundle: dict, model: str = "gpt-4o") -> dict:
        if not self.is_available():
            raise ValueError("OPENAI_API_KEY is absent. Please paste your OpenAI API key.")
        prompt = (
            "You are an expert GDPR/CCPA privacy compliance auditor. "
            "Analyze this deletion audit case bundle and determine the compliance status (COMPLETE, INCOMPLETE, or NOT_APPLICABLE). "
            "Return STRICT JSON with keys: "
            "\"status\" (COMPLETE|INCOMPLETE|NOT_APPLICABLE), "
            "\"confidence\" (float 0.0 to 1.0), "
            "\"reasoning\" (detailed explanation of your decision), "
            "\"findings\" (list of unpurged or leaked resources: [{system_id, resource_id, kind}]).\n\n"
            f"CASE BUNDLE:\n{json.dumps(bundle, default=str)}"
        )
        resp = self._client.chat.completions.create(
            model=model or "gpt-4o",
            messages=[
                {"role": "system", "content": "You are a senior data privacy compliance auditor. Always output valid JSON."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )
        return json.loads(resp.choices[0].message.content)


class DeepSeekClient:
    """DeepSeek API client using OpenAI-compatible interface with api.deepseek.com."""
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("DEEPSEEK_API_KEY")
        self._client = None
        if self.api_key and self.api_key.strip():
            try:
                from openai import OpenAI
                self._client = OpenAI(
                    api_key=self.api_key.strip(),
                    base_url="https://api.deepseek.com",
                )
            except Exception:
                self._client = None

    def is_available(self) -> bool:
        return self._client is not None

    def verify_case(self, bundle: dict, model: str = "deepseek-chat") -> dict:
        if not self.is_available():
            raise ValueError("DEEPSEEK_API_KEY is absent. Please paste your DeepSeek API key.")
        prompt = (
            "You are a GDPR & CCPA privacy compliance auditor. Analyze this deletion request case bundle. "
            "Examine identity graph clusters, unpurged residual data, and active data flows. "
            "Return STRICT JSON with keys: "
            "\"status\" (COMPLETE, INCOMPLETE, or NOT_APPLICABLE), "
            "\"confidence\" (float 0.0 to 1.0), "
            "\"reasoning\" (concise explanation of your audit verdict), "
            "\"findings\" (list of unpurged items: [{system_id, resource_id, kind}]).\n\n"
            f"CASE BUNDLE:\n{json.dumps(bundle, default=str)}"
        )
        resp = self._client.chat.completions.create(
            model=model or "deepseek-chat",
            messages=[
                {"role": "system", "content": "You are DeepSeek Privacy Audit Engine. Return valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )
        return json.loads(resp.choices[0].message.content)


class AnthropicClient:
    """Anthropic Claude API client."""
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = (api_key or os.environ.get("ANTHROPIC_API_KEY") or "").strip()

    def is_available(self) -> bool:
        return bool(self.api_key)

    def verify_case(self, bundle: dict, model: str = "claude-3-7-sonnet-20250219") -> dict:
        if not self.is_available():
            raise ValueError("ANTHROPIC_API_KEY is absent. Please paste your Anthropic API key.")
        url = "https://api.anthropic.com/v1/messages"
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        prompt = (
            "You are an expert GDPR & CCPA privacy compliance auditor. Analyze this deletion audit case bundle. "
            "Return ONLY raw JSON with keys: "
            "\"status\" (COMPLETE, INCOMPLETE, or NOT_APPLICABLE), "
            "\"confidence\" (float 0.0 to 1.0), "
            "\"reasoning\" (explanation of your audit verdict), "
            "\"findings\" (list of [{system_id, resource_id, kind}]).\n\n"
            f"CASE BUNDLE:\n{json.dumps(bundle, default=str)}"
        )
        
        # Candidate latest Claude models in priority order
        candidates = [model or "claude-3-7-sonnet-20250219", "claude-3-5-sonnet-latest", "claude-3-5-sonnet-20241022"]
        seen = set()
        unique_candidates = [c for c in candidates if c and not (c in seen or seen.add(c))]

        last_err = None
        for m in unique_candidates:
            body = {
                "model": m,
                "max_tokens": 1024,
                "messages": [{"role": "user", "content": prompt}]
            }
            try:
                r = requests.post(url, headers=headers, json=body, timeout=40)
                if r.status_code == 200:
                    data = r.json()
                    text = data["content"][0]["text"].strip()
                    if text.startswith("```json"):
                        text = text.replace("```json", "", 1).replace("```", "").strip()
                    elif text.startswith("```"):
                        text = text.replace("```", "", 1).replace("```", "").strip()
                    return json.loads(text)
                else:
                    last_err = f"{m} HTTP {r.status_code}: {r.text[:200]}"
            except Exception as e:
                last_err = f"{m} failed: {str(e)}"

        raise RuntimeError(f"All Anthropic model candidates failed: {last_err}")


class GeminiClient:
    """Google Gemini client using modern active models (strict zero deprecated models)."""
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = (api_key or os.environ.get("GEMINI_API_KEY") or "").strip()

    def is_available(self) -> bool:
        return bool(self.api_key)

    def verify_case(self, bundle: dict, model: str = "") -> dict:
        if not self.is_available():
            raise ValueError("GEMINI_API_KEY is absent. Please paste your Gemini API key.")

        prompt = (
            "You are a GDPR & CCPA privacy compliance auditor. Analyze this deletion request case bundle. "
            "Return strictly raw JSON with keys: "
            "\"status\" (COMPLETE, INCOMPLETE, or NOT_APPLICABLE), "
            "\"confidence\" (float 0.0 to 1.0), "
            "\"reasoning\" (explanation of your audit verdict), "
            "\"findings\" (list of [{system_id, resource_id, kind}]).\n\n"
            f"CASE BUNDLE:\n{json.dumps(bundle, default=str)}"
        )
        body = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"responseMimeType": "application/json"}
        }

        # Latest active Gemini models only (tested & supported: gemini-3.1-flash-lite, gemini-3.8-flash, gemini-flash-latest)
        # Note: gemini-2.0-flash and gemini-2.5-flash are deprecated / retired and strictly excluded.
        candidates = []
        if model and model not in ("gemini-2.0-flash", "gemini-2.5-flash", "gemini-1.5-flash"):
            candidates.append(model)
        candidates.extend(["gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-latest"])

        seen = set()
        unique_candidates = [c for c in candidates if c and not (c in seen or seen.add(c))]

        last_err = None
        for m in unique_candidates:
            target_url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent?key={self.api_key}"
            try:
                r = requests.post(target_url, json=body, timeout=20)
                if r.status_code == 200:
                    res_json = r.json()
                    raw_text = res_json["candidates"][0]["content"]["parts"][0]["text"].strip()
                    return json.loads(raw_text)
                else:
                    last_err = f"{m} HTTP {r.status_code}: {r.text[:200]}"
            except Exception as e:
                last_err = f"{m} failed: {str(e)}"

        raise RuntimeError(f"All Gemini model candidates failed: {last_err}")


class NullClient:
    """Null client used when no API key is present."""
    def is_available(self) -> bool:
        return False
    def verify_case(self, *a, **k):
        raise ValueError("API Key is absent. Please paste the API key.")
    def classify_na(self, *a, **k):
        return False