from __future__ import annotations
import json, os, threading
from datetime import datetime, timezone

_LOCK = threading.Lock()
_LOG_PATH = os.environ.get("AUDIT_USAGE_LOG", "evaluation/usage_log.jsonl")


def log_call(*, phase: str, provider: str, model: str,
             input_tokens: int, output_tokens: int, est_cost: float) -> None:
    os.makedirs(os.path.dirname(_LOG_PATH), exist_ok=True)
    rec = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "phase": phase, "provider": provider, "model": model,
        "input_tokens": int(input_tokens), "output_tokens": int(output_tokens),
        "est_cost": float(est_cost),
    }
    with _LOCK:
        with open(_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")