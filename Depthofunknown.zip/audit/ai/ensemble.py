from __future__ import annotations
import os, json
from typing import Optional
from audit.io.schemas import Case, Record, Activity, Rule, Step, Finding
from audit.core.timeline import state_at
from audit.core.step_builder import build_steps_complete, build_steps_incomplete

def _create_compact_bundle(case: Case, records: list[Record], activities: list[Activity], rules_by_cat: dict[str, Rule]) -> dict:
    """Builds clean structured case bundle for the AI models."""
    return {
        "case_id": case.case_id,
        "requester_email": case.email,
        "requested_at": case.requested_at.isoformat(),
        "reported_status": case.reported_status,
        "audit_at": case.audit_at.isoformat(),
        "request_text": case.request_text,
        "records": [
            {
                "system_id": r.system_id,
                "resource_id": r.resource_id,
                "data_category": r.data_category,
                "fields": {k: v for k, v in r.fields.items() if v},
                "treatment": getattr(rules_by_cat.get(r.data_category), "treatment", "RETAIN"),
                "state": state_at(r, case.audit_at)
            }
            for r in records[:50]
        ],
        "activities": [
            {
                "activity_id": a.activity_id,
                "system_id": a.system_id,
                "kind": a.kind,
                "status": a.status,
                "user_refs": a.scope.get("user_refs", [])
            }
            for a in activities[:30]
        ]
    }


def run_model_jury(
    cases: list[Case],
    records: list[Record],
    activities: list[Activity],
    rules_by_cat: dict[str, Rule],
    identities: list[dict],
    audit_log: list[dict],
    clients: dict[str, any], # {'deepseek': client, 'anthropic': client, 'openai': client, 'gemini': client}
) -> dict[str, any]:
    """
    Executes multi-model consensus audit across DeepSeek, Anthropic, OpenAI, and Gemini.
    STRICT: Zero simulation. If keys are absent, marks as KEY_ABSENT and displays message.
    """
    models = ["deepseek", "anthropic", "openai", "gemini"]

    # Check which clients have valid API keys
    available_models = [m for m in models if clients.get(m) and getattr(clients[m], "is_available", lambda: False)()]

    if not available_models:
        raise ValueError(
            "ALL_KEYS_ABSENT: No AI model API keys are configured (DeepSeek, Anthropic, OpenAI, or Gemini). "
            "Please paste your API key(s) to run AI generation, or click 'Run Rule-Based Pipeline' to use the deterministic rules engine."
        )

    model_outputs: dict[str, dict[str, tuple[str, list[Step]]]] = {m: {} for m in models}
    case_votes: dict[str, dict[str, any]] = {}

    for case in cases:
        cid = case.case_id
        bundle = _create_compact_bundle(case, records, activities, rules_by_cat)
        votes_for_case = {}

        for m in models:
            client = clients.get(m)
            if client is None or not getattr(client, "is_available", lambda: False)():
                # STRICT: No simulated data! Explicitly state key is absent.
                status = "KEY_ABSENT"
                steps: list[Step] = []
                reasoning = f"{m.capitalize()} API key is absent. Please paste {m.upper()}_API_KEY."
                conf = 0.0
            else:
                try:
                    # Real live call to AI model
                    resp = client.verify_case(bundle)
                    raw_status = (resp.get("status") or "INCOMPLETE").upper()
                    if raw_status in ("COMPLETE", "COMPLETED"):
                        status = "COMPLETE"
                    elif raw_status in ("NOT_APPLICABLE", "NOT APPLICABLE", "NA"):
                        status = "NOT_APPLICABLE"
                    else:
                        status = "INCOMPLETE"
                    reasoning = resp.get("reasoning", f"{m.capitalize()} live evaluation completed.")
                    conf = float(resp.get("confidence", 0.95))
                    
                    # Construct steps based on AI model's findings
                    findings_raw = resp.get("findings", [])
                    findings = [
                        Finding(
                            kind="REMAINING" if f.get("kind") not in ("EXPOSED_PII", "FLOW", "RESTORE") else f.get("kind"),
                            system_id=f.get("system_id", "ai_sys"),
                            resource_id=f.get("resource_id", "ai_res"),
                            evidence_id=""
                        )
                        for f in findings_raw
                    ]
                    if status == "COMPLETE":
                        steps = build_steps_complete([], [], rules_by_cat)
                    elif status == "NOT_APPLICABLE":
                        steps = []
                    else:
                        steps = build_steps_incomplete(findings, rules_by_cat, [])
                except Exception as e:
                    status = "ERROR"
                    steps = []
                    reasoning = f"API Error from {m}: {str(e)}"
                    conf = 0.0

            model_outputs[m][cid] = (status, steps)
            votes_for_case[m] = {
                "status": status,
                "step_count": len(steps),
                "confidence": conf,
                "reasoning": reasoning
            }

        # Supreme Judgement Synthesis across active models with keys
        consensus_status, consensus_steps, supreme_rationale, agreement_pct = adjudicate_consensus(
            case, votes_for_case, model_outputs, available_models
        )

        case_votes[cid] = {
            "votes": votes_for_case,
            "agreement_pct": agreement_pct,
            "supreme_status": consensus_status,
            "supreme_steps": consensus_steps,
            "supreme_rationale": supreme_rationale
        }

    return {
        "model_outputs": model_outputs,
        "case_votes": case_votes,
        "available_models": available_models
    }


def adjudicate_consensus(
    case: Case,
    votes: dict[str, any],
    model_outputs: dict[str, dict[str, tuple[str, list[Step]]]],
    available_models: list[str]
) -> tuple[str, list[Step], str, float]:
    """
    Supreme Judgement Arbitrator:
    Synthesizes verdicts strictly from models that have valid keys.
    """
    # Only count votes from models that ran (exclude KEY_ABSENT and ERROR)
    valid_votes = {m: v for m, v in votes.items() if m in available_models and v["status"] not in ("KEY_ABSENT", "ERROR")}

    if not valid_votes:
        return "KEY_ABSENT", [], "Cannot determine consensus: all model keys are absent.", 0.0

    statuses = [v["status"] for v in valid_votes.values()]
    counts = {}
    for s in statuses:
        counts[s] = counts.get(s, 0) + 1

    majority_status = max(counts.items(), key=lambda x: x[1])[0]
    agreement_pct = (counts[majority_status] / len(statuses)) * 100.0

    # Pick steps from the highest confidence model that voted for majority status
    canonical_steps: list[Step] = []
    for m in valid_votes:
        st, steps = model_outputs[m].get(case.case_id, ("", []))
        if st == majority_status and steps:
            canonical_steps = steps
            break

    voter_summary = ", ".join([f"{m.capitalize()}={valid_votes[m]['status']}" for m in valid_votes])
    absent_models = [m.capitalize() for m in votes if votes[m]["status"] == "KEY_ABSENT"]
    absent_note = f" (Keys absent for: {', '.join(absent_models)})" if absent_models else ""

    rationale = (
        f"Supreme AI Judgement: {majority_status} ({counts[majority_status]}/{len(valid_votes)} active models: {voter_summary}){absent_note}."
    )

    return majority_status, canonical_steps, rationale, agreement_pct
