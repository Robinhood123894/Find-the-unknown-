from __future__ import annotations
import argparse, json, os, sys
import pandas as pd
from audit.validate.validator import validate_output
from audit.io.schemas import Step

def _read_pipeline_csv(path: str) -> dict[str, tuple[str, list[Step]]]:
    df = pd.read_csv(path, dtype=str).fillna("")
    out = {}
    for _, r in df.iterrows():
        steps_raw = json.loads(r["steps_json"]) if r["steps_json"].strip() else []
        steps = [Step(**s) for s in steps_raw]
        out[r["case_id"]] = (r["deletion_status"], steps)
    return out


def finalize(run_dir: str, dataset: str, output_path: str):
    a_path = os.path.join(run_dir, "output_rules.csv")
    b_path = os.path.join(run_dir, "output_ai.csv")
    ledger_path = os.path.join(run_dir, "review_state.json")
    if not os.path.exists(ledger_path):
        print("No review_state.json — cannot finalize without approval.")
        sys.exit(1)
    with open(ledger_path, "r", encoding="utf-8") as f:
        ledger = json.load(f)

    results_a = _read_pipeline_csv(a_path) if os.path.exists(a_path) else {}
    results_b = _read_pipeline_csv(b_path) if os.path.exists(b_path) else {}

    df_cases = pd.read_csv(os.path.join(dataset, "deletion_requests.csv"), dtype=str).fillna("")
    expected_ids = df_cases["case_id"].tolist()

    final = {}
    missing = []
    for cid in expected_ids:
        decision = ledger.get("cases", {}).get(cid)
        if not decision:
            missing.append(cid); continue
        d = decision["decision"]
        if d == "A" and cid in results_a:
            final[cid] = results_a[cid]
        elif d == "B" and cid in results_b:
            final[cid] = results_b[cid]
        elif cid in results_b:
            final[cid] = results_b[cid]
        elif cid in results_a:
            final[cid] = results_a[cid]
        else:
            missing.append(cid)

    if missing:
        print(f"Cannot finalize: {len(missing)} unapproved/missing cases.")
        sys.exit(1)

    errs = validate_output(final, expected_ids)
    if errs:
        print("Validation errors:", errs[:10])
        sys.exit(1)

    # write final CSV
    lines = ["case_id,deletion_status,steps_json"]
    for cid in sorted(final.keys()):
        status, steps = final[cid]
        payload = json.dumps([s.model_dump() for s in steps], separators=(",", ":"), default=str)
        lines.append(f'{cid},{status},"{payload.replace(chr(34), chr(34)*2)}"')
    with open(output_path, "w", encoding="utf-8", newline="") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Wrote {output_path} with {len(final)} rows.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--dataset", default="dataset")
    ap.add_argument("--output", default="output.csv")
    args = ap.parse_args()
    finalize(args.run_dir, args.dataset, args.output)