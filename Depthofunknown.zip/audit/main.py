from __future__ import annotations
import argparse, os, sys, json
from datetime import datetime, timezone
import pandas as pd

from audit.io import loaders
from audit.io.evidence_manifest import resolve_manifest
from audit.extract.cache import DiskCache
from audit.extract.router import route
from audit.ai.client import OpenAIClient, NullClient
from audit.ai import usage  # noqa: F401 ensures log path set
from audit.pipeline_a import evaluate_case as eval_a
from audit.pipeline_b import evaluate_case as eval_b
from audit.validate.validator import validate_output


def _load_yaml(path):
    import yaml
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _write_csv(path, rows: dict[str, tuple[str, list]]):
    ordered = sorted(rows.keys())
    lines = ["case_id,deletion_status,steps_json"]
    for cid in ordered:
        status, steps = rows[cid]
        steps_payload = [s.model_dump() for s in steps]
        steps_json = json.dumps(steps_payload, separators=(",", ":"), default=str)
        # CSV-escape the JSON string
        escaped = '"' + steps_json.replace('"', '""') + '"'
        lines.append(f"{cid},{status},{escaped}")
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write("\n".join(lines) + "\n")


def _run_pipeline(cases, records, activities, rules_by_cat, identities, audit_log,
                  na_client, na_model,
                  pipeline: str,
                  verifier_client=None, verifier_model="", verifier_retries=0):
    results = {}
    for case in cases:
        if pipeline == "a":
            status, steps, meta = eval_a(
                case, records, activities, rules_by_cat,
                identities, audit_log, na_client, na_model)
        else:
            status, steps, meta = eval_b(
                case, records, activities, rules_by_cat,
                identities, audit_log, na_client, na_model,
                verifier_client, verifier_model, verifier_retries)
        results[case.case_id] = (status, steps)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="dataset")
    ap.add_argument("--mode", choices=["rules", "ai", "both"], default="both")
    ap.add_argument("--out-dir", default=None)
    args = ap.parse_args()

    dataset = args.dataset
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = args.out_dir or os.path.join("runs", ts)
    os.makedirs(run_dir, exist_ok=True)

    models_cfg = _load_yaml("config/models.yaml")
    paths_cfg = _load_yaml("config/paths.yaml")
    cache = DiskCache(os.path.join(run_dir, ".cache"))

    cases = loaders.load_requests(os.path.join(dataset, "deletion_requests.csv"))
    identities = loaders.load_identities(os.path.join(dataset, "user_identities.csv"))
    audit_log = loaders.load_audit_log(os.path.join(dataset, "user_audit_log.csv"))
    activities = loaders.load_activity(os.path.join(dataset, "system_activity.csv"))
    rules = loaders.load_rules(os.path.join(dataset, "deletion_rules.csv"))
    manifest = loaders.load_evidence_manifest(os.path.join(dataset, "evidence_files.csv"))
    manifest = resolve_manifest(manifest, dataset)

    api_key = os.environ.get("OPENAI_API_KEY", "")
    client = OpenAIClient(api_key) if api_key else NullClient()

    # extraction (shared)
    ext = route(manifest, cache)
    records = ext.records
    activities = activities + ext.activities

    na_model = models_cfg.get("na_classifier", {}).get("model", "gpt-4o-mini")
    verifier_model = models_cfg.get("verifier", {}).get("model", "gpt-4o-mini")
    verifier_retries = int(models_cfg.get("verifier", {}).get("max_retries_per_case", 2))

    expected_ids = [c.case_id for c in cases]

    if args.mode in ("rules", "both"):
        print("[pipeline A] rules-only ...")
        results_a = _run_pipeline(cases, records, activities, rules, identities, audit_log,
                                  client, na_model, pipeline="a")
        errs = validate_output(results_a, expected_ids)
        if errs:
            print("[pipeline A] validation errors:", errs[:5])
        out_a = os.path.join(run_dir, "output_rules.csv")
        _write_csv(out_a, results_a)
        print(f"[pipeline A] wrote {out_a}")

    if args.mode in ("ai", "both"):
        print("[pipeline B] rules + verifier ...")
        results_b = _run_pipeline(cases, records, activities, rules, identities, audit_log,
                                  client, na_model, pipeline="b",
                                  verifier_client=client, verifier_model=verifier_model,
                                  verifier_retries=verifier_retries)
        errs = validate_output(results_b, expected_ids)
        if errs:
            print("[pipeline B] validation errors:", errs[:5])
        out_b = os.path.join(run_dir, "output_ai.csv")
        _write_csv(out_b, results_b)
        print(f"[pipeline B] wrote {out_b}")

    print(f"[done] run_dir={run_dir}")


if __name__ == "__main__":
    main()