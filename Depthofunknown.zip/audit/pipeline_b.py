from __future__ import annotations
from audit.io.schemas import (
    Case, Activity, Record, Rule, Step, Finding
)
from audit.core.identity_graph import build_cluster, record_matches_cluster
from audit.core.timeline import state_at
from audit.core.policy import classify_record
from audit.core.risk_detector import detect_flows, detect_restore_risks
from audit.core.status_decider import decide
from audit.core.na_classifier import is_deletion_request
from audit.core.step_builder import build_steps_incomplete, build_steps_complete
from audit.ai.verifier import verify_and_refine


def evaluate_case(
    case: Case,
    records: list[Record],
    activities: list[Activity],
    rules_by_cat: dict[str, Rule],
    identities: list[dict],
    audit_log: list[dict],
    na_client,
    na_model: str,
    verifier_client,
    verifier_model: str,
    verifier_max_retries: int,
) -> tuple[str, list[Step], dict]:
    cluster = build_cluster(case, identities, audit_log, records)
    is_del, na_reason = is_deletion_request(case, na_client, na_model)
    if not is_del:
        return "NOT_APPLICABLE", [], {"cluster_size": len(cluster.identifiers), "na_reason": na_reason}

    relevant = [r for r in records if record_matches_cluster(r, cluster)]
    findings: list[Finding] = []
    retained: list[Record] = []
    clean: list[Record] = []

    for r in relevant:
        state = state_at(r, case.audit_at)
        rule = rules_by_cat.get(r.data_category)
        if rule and rule.treatment == "RETAIN" and state != "ABSENT":
            retained.append(r); continue
        f = classify_record(r, state, rule, cluster)
        if f:
            findings.append(f)
        elif state != "ABSENT":
            clean.append(r)

    findings.extend(detect_flows(activities, cluster, case.audit_at))
    findings.extend(detect_restore_risks(activities, cluster, case.audit_at))

    findings, retained, clean, verifier_report = verify_and_refine(
        case=case, cluster=cluster, records=relevant, activities=activities,
        findings=findings, retained=retained, clean=clean,
        rules_by_cat=rules_by_cat,
        client=verifier_client, model=verifier_model,
        max_retries=verifier_max_retries,
    )

    retained_ok = len(retained) > 0 or True
    status = decide(True, findings, retained_ok)

    if status == "COMPLETE":
        steps = build_steps_complete(retained, clean, rules_by_cat)
    else:
        steps = build_steps_incomplete(findings, rules_by_cat, retained)

    return status, steps, {
        "cluster_size": len(cluster.identifiers),
        "relevant_records": len(relevant),
        "findings": len(findings),
        "retained": len(retained),
        "verifier": verifier_report,
    }