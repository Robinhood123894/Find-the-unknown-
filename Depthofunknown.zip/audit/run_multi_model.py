from __future__ import annotations
import os, sys, json
from datetime import datetime, timezone
import pandas as pd
from audit.io import loaders
from audit.io.evidence_manifest import resolve_manifest
from audit.extract.cache import DiskCache
from audit.extract.router import route
from audit.ai.client import OpenAIClient, DeepSeekClient, AnthropicClient, GeminiClient, NullClient
from audit.ai.ensemble import run_model_jury

def main():
    dataset = "dataset"
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = os.path.join("runs", f"consensus_{ts}")
    os.makedirs(run_dir, exist_ok=True)

    cache = DiskCache(os.path.join(run_dir, ".cache"))
    cases = loaders.load_requests(os.path.join(dataset, "deletion_requests.csv"))
    identities = loaders.load_identities(os.path.join(dataset, "user_identities.csv"))
    audit_log = loaders.load_audit_log(os.path.join(dataset, "user_audit_log.csv"))
    activities = loaders.load_activity(os.path.join(dataset, "system_activity.csv"))
    rules = loaders.load_rules(os.path.join(dataset, "deletion_rules.csv"))
    manifest = loaders.load_evidence_manifest(os.path.join(dataset, "evidence_files.csv"))
    manifest = resolve_manifest(manifest, dataset)

    # Extraction
    ext = route(manifest, cache)
    records = ext.records
    activities = activities + ext.activities

    # Clients for each model
    deepseek_key = os.environ.get("DEEPSEEK_API_KEY", "")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    openai_key = os.environ.get("OPENAI_API_KEY", "")
    gemini_key = os.environ.get("GEMINI_API_KEY", "")

    clients = {
        "deepseek": DeepSeekClient(deepseek_key) if deepseek_key else NullClient(),
        "anthropic": AnthropicClient(anthropic_key) if anthropic_key else NullClient(),
        "openai": OpenAIClient(openai_key) if openai_key else NullClient(),
        "gemini": GeminiClient(gemini_key) if gemini_key else NullClient(),
    }

    # Execute Multi-Model Ensemble
    result = run_model_jury(cases, records, activities, rules, identities, audit_log, clients)

    model_outputs = result["model_outputs"]
    case_votes = result["case_votes"]

    # Write individual model CSVs
    def write_csv(filepath, case_dict):
        lines = ["case_id,deletion_status,steps_json"]
        for cid in sorted(case_dict.keys()):
            status, steps = case_dict[cid]
            payload = [s.model_dump() for s in steps]
            json_str = json.dumps(payload, separators=(",", ":"), default=str)
            lines.append(f'{cid},{status},"{json_str.replace(chr(34), chr(34)*2)}"')
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            f.write("\n".join(lines) + "\n")

    for model_name, case_dict in model_outputs.items():
        write_csv(os.path.join(run_dir, f"output_{model_name}.csv"), case_dict)

    # Write Supreme Consensus CSV
    consensus_dict = {}
    for cid, cv in case_votes.items():
        consensus_dict[cid] = (cv["supreme_status"], cv["supreme_steps"])
    
    consensus_path = os.path.join(run_dir, "output_consensus.csv")
    write_csv(consensus_path, consensus_dict)
    # Also update global output.csv
    write_csv("output.csv", consensus_dict)

    # Write jury report JSON
    report_path = os.path.join(run_dir, "jury_report.json")
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump({
            "run_dir": run_dir,
            "case_votes": {
                cid: {
                    "votes": cv["votes"],
                    "agreement_pct": cv["agreement_pct"],
                    "supreme_status": cv["supreme_status"],
                    "supreme_rationale": cv["supreme_rationale"],
                    "step_count": len(cv["supreme_steps"]),
                    "steps": [s.model_dump() for s in cv["supreme_steps"]]
                }
                for cid, cv in case_votes.items()
            }
        }, f, indent=2, default=str)

    print(json.dumps({
        "success": True,
        "run_dir": run_dir,
        "cases_count": len(cases),
        "consensus_path": consensus_path
    }))

if __name__ == "__main__":
    main()
