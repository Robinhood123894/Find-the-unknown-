from __future__ import annotations
import json, os
from collections import defaultdict

def usage_report(log_path: str, out_path: str, n_requests: int):
    per_model = defaultdict(lambda: {"calls": 0, "in": 0, "out": 0, "cost": 0.0})
    total = {"calls": 0, "in": 0, "out": 0, "cost": 0.0}
    if os.path.exists(log_path):
        with open(log_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                key = f'{r["provider"]}/{r["model"]}'
                per_model[key]["calls"] += 1
                per_model[key]["in"] += r["input_tokens"]
                per_model[key]["out"] += r["output_tokens"]
                per_model[key]["cost"] += r["est_cost"]
                total["calls"] += 1
                total["in"] += r["input_tokens"]
                total["out"] += r["output_tokens"]
                total["cost"] += r["est_cost"]
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# Usage Report\n\n")
        f.write(f"Requests: {n_requests}\n\n")
        f.write("## Per-model\n\n")
        f.write("| provider/model | calls | input | output | cost (USD) |\n|---|---|---|---|---|\n")
        for k, v in sorted(per_model.items()):
            f.write(f"| {k} | {v['calls']} | {v['in']} | {v['out']} | {v['cost']:.4f} |\n")
        f.write("\n## Total\n\n")
        f.write(f"- Calls: {total['calls']}\n- Input tokens: {total['in']}\n- Output tokens: {total['out']}\n")
        f.write(f"- Estimated cost: ${total['cost']:.4f}\n")
        if n_requests:
            f.write(f"- Tokens per request: {(total['in']+total['out'])/n_requests:.2f}\n")
            f.write(f"- Cost per request: ${total['cost']/n_requests:.6f}\n")