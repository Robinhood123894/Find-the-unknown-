from __future__ import annotations
import json, sys
import pandas as pd

def compare(pred_csv: str, gold_csv: str) -> dict:
    pred = pd.read_csv(pred_csv, dtype=str).fillna("")
    gold = pd.read_csv(gold_csv, dtype=str).fillna("")
    p = {r["case_id"]: r for _, r in pred.iterrows()}
    g = {r["case_id"]: r for _, r in gold.iterrows()}

    ids = sorted(set(p.keys()) | set(g.keys()))
    status_ok = 0
    seq_ok = 0
    for cid in ids:
        if cid not in p or cid not in g:
            continue
        if p[cid]["deletion_status"] == g[cid]["deletion_status"]:
            status_ok += 1
        try:
            pj = json.loads(p[cid]["steps_json"]) if p[cid]["steps_json"] else []
            gj = json.loads(g[cid]["steps_json"]) if g[cid]["steps_json"] else []
            if pj == gj:
                seq_ok += 1
        except Exception:
            pass
    return {
        "cases": len(ids),
        "status_accuracy": status_ok / max(1, len(ids)),
        "exact_sequence_match": seq_ok / max(1, len(ids)),
    }

if __name__ == "__main__":
    print(compare(sys.argv[1], sys.argv[2]))