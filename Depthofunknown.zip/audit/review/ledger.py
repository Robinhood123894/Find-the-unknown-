from __future__ import annotations
import json, os
from datetime import datetime, timezone

def load_ledger(run_dir: str) -> dict:
    p = os.path.join(run_dir, "review_state.json")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"run_dir": run_dir, "cases": {}}

def save_ledger(run_dir: str, ledger: dict) -> None:
    p = os.path.join(run_dir, "review_state.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(ledger, f, indent=2)

def approve(ledger: dict, case_id: str, decision: str, note: str = "") -> None:
    ledger["cases"][case_id] = {
        "decision": decision,
        "at": datetime.now(timezone.utc).isoformat(),
        "note": note,
    }