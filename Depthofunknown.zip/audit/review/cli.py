from __future__ import annotations
import os, sys
import pandas as pd
from audit.review import ledger as ledger_mod

def run_review(run_dir: str):
    diff_path = os.path.join(run_dir, "output_diff.csv")
    if not os.path.exists(diff_path):
        print("No diff to review.")
        return
    df = pd.read_csv(diff_path, dtype=str).fillna("")
    led = ledger_mod.load_ledger(run_dir)

    # auto approve identical
    import yaml
    cfg = {}
    if os.path.exists("config/review.yaml"):
        with open("config/review.yaml", "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    auto = cfg.get("auto_approve_identical", True)

    if auto:
        for _, r in df.iterrows():
            if r["suggested_decision"] == "IDENTICAL" and r["case_id"] not in led["cases"]:
                ledger_mod.approve(led, r["case_id"], "A", note="auto-identical")
        ledger_mod.save_ledger(run_dir, led)

    todo = [r for _, r in df.iterrows() if r["case_id"] not in led["cases"]]
    print(f"Cases to review: {len(todo)}")
    for r in todo:
        cid = r["case_id"]
        print(f"\n=== {cid} ===  status_A={r['status_A']}  status_B={r['status_B']}")
        while True:
            ans = input("[a]pprove A  [b]pprove B  [s]kip  [q]uit > ").strip().lower()
            if ans in ("a", "b"):
                ledger_mod.approve(led, cid, ans.upper())
                ledger_mod.save_ledger(run_dir, led)
                break
            if ans == "s":
                break
            if ans == "q":
                return
    ledger_mod.save_ledger(run_dir, led)
    print("Review complete.")