from __future__ import annotations
import json, os
import pandas as pd

def build_diff(run_dir: str) -> str:
    a_path = os.path.join(run_dir, "output_rules.csv")
    b_path = os.path.join(run_dir, "output_ai.csv")
    if not (os.path.exists(a_path) and os.path.exists(b_path)):
        return ""
    df_a = pd.read_csv(a_path, dtype=str).fillna("")
    df_b = pd.read_csv(b_path, dtype=str).fillna("")
    merged = df_a.merge(df_b, on="case_id", suffixes=("_A", "_B"), how="outer").fillna("")
    rows = []
    for _, r in merged.iterrows():
        same = (r["deletion_status_A"] == r["deletion_status_B"]) and (r["steps_json_A"] == r["steps_json_B"])
        rows.append({
            "case_id": r["case_id"],
            "status_A": r["deletion_status_A"],
            "status_B": r["deletion_status_B"],
            "status_same": r["deletion_status_A"] == r["deletion_status_B"],
            "steps_same": r["steps_json_A"] == r["steps_json_B"],
            "suggested_decision": "IDENTICAL" if same else "REVIEW",
        })
    diff_path = os.path.join(run_dir, "output_diff.csv")
    pd.DataFrame(rows).to_csv(diff_path, index=False)

    md_path = os.path.join(run_dir, "output_diff.md")
    total = len(rows)
    identical = sum(1 for r in rows if r["suggested_decision"] == "IDENTICAL")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# Diff Report\n\nTotal: {total}\nIdentical: {identical}\nReview: {total-identical}\n")
    return diff_path