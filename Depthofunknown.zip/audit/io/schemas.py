from __future__ import annotations
from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel, Field

EventType = Literal[
    "CREATE", "DELETE", "REDACT", "ANONYMIZE",
    "RESTORE", "SYNC_WRITE", "INDEX", "EXPORT",
]

ActivityKind = Literal[
    "delete", "sync", "import", "export", "index",
    "backup", "restore", "other",
]

ActivityStatus = Literal["active", "inactive", "completed", "failed"]

State = Literal["ABSENT", "PRESENT", "PRESENT_REDACTED", "PRESENT_ANONYMIZED"]

Treatment = Literal["DELETE", "REDACT", "ANONYMIZE", "RETAIN"]

StepPhase = Literal["FINDING", "REMEDIATION", "VERIFICATION"]

Operation = Literal[
    "REPORT_REMAINING_RECORD", "REPORT_EXPOSED_PII",
    "REPORT_ACTIVE_DATA_FLOW", "REPORT_RESTORE_RISK",
    "DISABLE_DATA_FLOW", "BLOCK_RESTORE",
    "DELETE_RECORD", "REDACT_RECORD", "ANONYMIZE_RECORD",
    "VERIFY_RECORD_ABSENT", "VERIFY_RECORD_PRESENT",
    "VERIFY_RECORD_REDACTED", "VERIFY_RECORD_ANONYMIZED",
    "VERIFY_DATA_FLOW_DISABLED", "VERIFY_RESTORE_BLOCKED",
]

OperationState = Literal[
    "PRESENT", "ACTIVE", "DISABLED", "BLOCKED",
    "ABSENT", "REDACTED", "ANONYMIZED",
]

DeletionStatus = Literal["COMPLETE", "INCOMPLETE", "NOT_APPLICABLE"]


class StateEvent(BaseModel):
    ts: datetime
    event: EventType
    evidence_id: str


class Record(BaseModel):
    record_uid: str
    system_id: str
    resource_id: str
    data_category: str
    fields: dict[str, Optional[str]] = Field(default_factory=dict)
    state_events: list[StateEvent] = Field(default_factory=list)
    source_evidence_id: str = ""


class Activity(BaseModel):
    activity_id: str
    system_id: str
    kind: ActivityKind
    status: ActivityStatus
    started_at: datetime
    ended_at: Optional[datetime] = None
    scope: dict = Field(default_factory=dict)
    evidence_id: str = ""


class IdentityCluster(BaseModel):
    case_id: str
    identifiers: set[str] = Field(default_factory=set)
    primary_user_id: Optional[str] = None
    sources: list[str] = Field(default_factory=list)


class Rule(BaseModel):
    data_category: str
    treatment: Treatment
    fields_to_remove: list[str] = Field(default_factory=list)
    keep_fields: list[str] = Field(default_factory=list)
    is_tombstone: bool = False


class Case(BaseModel):
    case_id: str
    email: str
    requested_at: datetime
    reported_status: str
    reported_at: Optional[datetime] = None
    audit_at: datetime
    request_text: str = ""


class Finding(BaseModel):
    kind: Literal["REMAINING", "EXPOSED_PII", "FLOW", "RESTORE"]
    system_id: str
    resource_id: str
    evidence_id: str
    data_category: Optional[str] = None
    activity_id: Optional[str] = None


class Step(BaseModel):
    step_no: int
    phase: StepPhase
    system_id: str
    resource_id: str
    operation: Operation
    state: OperationState
    evidence_id: str = ""