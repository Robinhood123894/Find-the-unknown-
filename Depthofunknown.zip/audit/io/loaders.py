from __future__ import annotations
import os
from datetime import datetime, timezone
from typing import Optional
import pandas as pd
from .schemas import (
    Case, Activity, Rule, StateEvent, Record
)

def _parse_dt(val) -> Optional[datetime]:
    if val is None or (isinstance(val, float) and pd.isna(val)):
        return None
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    s = str(val).strip()
    if not s or s.lower() in ("nan", "none", ""):
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S"):
            try:
                return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
            except Exception:
                pass
    return None


def load_requests(path: str) -> list[Case]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    if df.empty:
        return []
    
    # Robust column mapping for uploaded CSVs with varying headers
    col_lookup = {str(c).strip().lower().replace(" ", "_").replace("-", "_"): str(c) for c in df.columns}
    
    # Locate case identifier column
    cid_col = None
    for cand in ["case_id", "caseid", "case", "id", "request_id", "req_id"]:
        if cand in col_lookup:
            cid_col = col_lookup[cand]
            break
    if cid_col is None and len(df.columns) > 0:
        cid_col = df.columns[0]
        
    email_col = None
    for cand in ["email", "user_email", "requester_email", "mail"]:
        if cand in col_lookup:
            email_col = col_lookup[cand]
            break
            
    req_at_col = None
    for cand in ["requested_at", "request_date", "created_at", "timestamp"]:
        if cand in col_lookup:
            req_at_col = col_lookup[cand]
            break

    rep_status_col = None
    for cand in ["reported_status", "status", "reportedstatus"]:
        if cand in col_lookup:
            rep_status_col = col_lookup[cand]
            break

    rep_at_col = None
    for cand in ["reported_at", "completed_at"]:
        if cand in col_lookup:
            rep_at_col = col_lookup[cand]
            break

    audit_at_col = None
    for cand in ["audit_at", "auditat", "reported_at", "requested_at"]:
        if cand in col_lookup:
            audit_at_col = col_lookup[cand]
            break

    req_text_col = None
    for cand in ["request_text", "request", "text", "description", "reason", "notes"]:
        if cand in col_lookup:
            req_text_col = col_lookup[cand]
            break

    cases: list[Case] = []
    for idx, row in df.iterrows():
        raw_cid = str(row[cid_col]).strip() if cid_col and cid_col in row else ""
        cid = raw_cid if raw_cid else f"CASE-{idx+1:03d}"
        
        email = str(row[email_col]).strip().lower() if email_col and email_col in row else ""
        status = str(row[rep_status_col]).strip().upper() if rep_status_col and rep_status_col in row else "COMPLETE"
        text = str(row[req_text_col]).strip() if req_text_col and req_text_col in row else ""
        
        req_dt = _parse_dt(row.get(req_at_col)) if req_at_col else None
        rep_dt = _parse_dt(row.get(rep_at_col)) if rep_at_col else None
        audit_dt = _parse_dt(row.get(audit_at_col)) if audit_at_col else None
        
        effective_audit = audit_dt or rep_dt or req_dt or datetime.now(timezone.utc)
        effective_req = req_dt or rep_dt or effective_audit

        cases.append(Case(
            case_id=cid,
            email=email,
            requested_at=effective_req,
            reported_status=status or "COMPLETE",
            reported_at=rep_dt,
            audit_at=effective_audit,
            request_text=text,
        ))
    return cases


def load_identities(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    return df.to_dict(orient="records")


def load_audit_log(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    rows = []
    for _, row in df.iterrows():
        ts = _parse_dt(row.get("changed_at") or row.get("timestamp") or row.get("audit_at"))
        rows.append({
            "ts": ts,
            "old_value": (row.get("old_value") or row.get("old") or "").strip().lower(),
            "new_value": (row.get("new_value") or row.get("new") or "").strip().lower(),
            "identifier_type": (row.get("identifier_type") or row.get("field") or "").strip().lower(),
            "user_id": (row.get("user_id") or "").strip(),
            "audit_id": (row.get("audit_id") or "").strip(),
        })
    return rows


def load_activity(path: str) -> list[Activity]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    out: list[Activity] = []
    for _, row in df.iterrows():
        kind = (row.get("activity_type") or row.get("kind") or row.get("type") or "other").strip().lower()
        if kind not in ("delete", "sync", "import", "export", "index", "backup", "restore", "other"):
            kind = "other"
        status = (row.get("status") or "").strip().lower()
        if status not in ("active", "inactive", "completed", "failed"):
            status = "completed" if row.get("ended_at") else "active"
        scope = {}
        cats = (row.get("data_categories") or row.get("data_category") or "").strip()
        if cats:
            scope["data_categories"] = [c.strip() for c in cats.split(",") if c.strip()]
        urefs = (row.get("user_refs") or row.get("user_ref") or row.get("email") or "").strip()
        if urefs:
            scope["user_refs"] = [u.strip().lower() for u in urefs.split(",") if u.strip()]
        out.append(Activity(
            activity_id=(row.get("activity_id") or "").strip(),
            system_id=(row.get("system_id") or "").strip(),
            kind=kind,
            status=status,
            started_at=_parse_dt(row.get("started_at") or row.get("requested_at") or row.get("audit_at")) or datetime.now(timezone.utc),
            ended_at=_parse_dt(row.get("ended_at")),
            scope=scope,
            evidence_id=(row.get("evidence_id") or row.get("activity_id") or "").strip(),
        ))
    return out


def load_rules(path: str) -> dict[str, Rule]:
    if not os.path.exists(path):
        return {}
    df = pd.read_csv(path, dtype=str).fillna("")
    out: dict[str, Rule] = {}
    for _, row in df.iterrows():
        cat = (row.get("data_category") or "").strip()
        if not cat:
            continue
        treatment = (row.get("treatment") or row.get("action") or "RETAIN").strip().upper()
        if treatment not in ("DELETE", "REDACT", "ANONYMIZE", "RETAIN"):
            treatment = "RETAIN"
        fields = [f.strip() for f in (row.get("fields_to_remove") or "").split(",") if f.strip()]
        keep = [f.strip() for f in (row.get("keep_fields") or "").split(",") if f.strip()]
        is_tomb = (row.get("is_tombstone") or "").strip().lower() in ("true", "1", "yes")
        out[cat] = Rule(
            data_category=cat, treatment=treatment,
            fields_to_remove=fields, keep_fields=keep, is_tombstone=is_tomb,
        )
    return out


def load_evidence_manifest(path: str) -> list[dict]:
    if not os.path.exists(path):
        return []
    df = pd.read_csv(path, dtype=str).fillna("")
    return df.to_dict(orient="records")