from __future__ import annotations
import os

def resolve_manifest(manifest: list[dict], dataset_dir: str) -> list[dict]:
    ev_dir = os.path.join(dataset_dir, "evidence")
    out = []
    for row in manifest:
        fid = (row.get("file_id") or row.get("evidence_id") or "").strip()
        rel = (row.get("file_path") or row.get("path") or "").strip()
        if not fid:
            continue
        if rel and not os.path.isabs(rel):
            abs_path = os.path.join(dataset_dir, rel)
            if not os.path.exists(abs_path):
                abs_path = os.path.join(ev_dir, os.path.basename(rel))
        else:
            abs_path = rel
        ftype = (row.get("file_type") or row.get("type") or os.path.splitext(rel)[1].lstrip(".")).lower()
        out.append({
            "file_id": fid, "path": abs_path, "type": ftype,
            "exists": os.path.exists(abs_path) if abs_path else False,
        })
    return out