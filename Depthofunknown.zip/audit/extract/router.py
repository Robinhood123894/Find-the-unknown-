from __future__ import annotations
import os
from typing import Optional
from audit.io.schemas import Record, Activity
from audit.extract.cache import DiskCache
from audit.extract import structured, logs, pdf_text

class ExtractionResult:
    def __init__(self):
        self.records: list[Record] = []
        self.activities: list[Activity] = []
        self.extraction_failures: list[str] = []

    def extend(self, records, activities, file_id):
        self.records.extend(records)
        self.activities.extend(activities)

    def fail(self, file_id):
        self.extraction_failures.append(file_id)


def route(manifest: list[dict], cache: DiskCache, vision_fn=None, log_ai_fn=None) -> ExtractionResult:
    res = ExtractionResult()
    for entry in manifest:
        if not entry.get("exists"):
            res.fail(entry.get("file_id", "?"))
            continue
        path = entry["path"]
        ftype = entry["type"]
        fid = entry["file_id"]
        system_hint = entry.get("system_id", "")
        try:
            key = DiskCache.hash_file(path)
            cached = cache.get(key)
            if cached is not None:
                recs = [Record(**r) for r in cached.get("records", [])]
                acts = [Activity(**a) for a in cached.get("activities", [])]
                res.extend(recs, acts, fid)
                continue

            recs, acts = [], []
            if ftype in ("json", "jsonl"):
                recs, acts = structured.parse_json(path, fid, system_hint)
            elif ftype == "csv":
                recs, acts = structured.parse_csv_evidence(path, fid, system_hint)
            elif ftype == "sql":
                recs, acts = structured.parse_sqlite_dump(path, fid, system_hint)
            elif ftype in ("log", "txt"):
                recs, acts, unmatched = logs.parse_log(path, fid, system_hint)
                if unmatched and log_ai_fn is not None:
                    extra_recs, extra_acts = log_ai_fn(unmatched, fid)
                    recs.extend(extra_recs)
                    acts.extend(extra_acts)
            elif ftype == "pdf":
                txt = pdf_text.extract_text(path)
                if txt:
                    tmp = path + ".extracted.txt"
                    try:
                        with open(tmp, "w", encoding="utf-8") as f:
                            f.write(txt)
                        recs, acts, _ = logs.parse_log(tmp, fid, system_hint)
                    finally:
                        try:
                            os.remove(tmp)
                        except Exception:
                            pass
                elif vision_fn is not None:
                    recs, acts = vision_fn(path, fid)
            elif ftype in ("png", "jpg", "jpeg"):
                if vision_fn is not None:
                    recs, acts = vision_fn(path, fid)
            else:
                if vision_fn is not None:
                    recs, acts = vision_fn(path, fid)

            cache.put(key, {
                "records": [r.model_dump() for r in recs],
                "activities": [a.model_dump() for a in acts],
            })
            res.extend(recs, acts, fid)
        except Exception:
            res.fail(fid)
    return res