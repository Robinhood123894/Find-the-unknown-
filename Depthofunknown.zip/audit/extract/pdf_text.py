from __future__ import annotations

def extract_text(path: str) -> str:
    try:
        from pypdf import PdfReader
        r = PdfReader(path)
        parts = []
        for p in r.pages:
            try:
                parts.append(p.extract_text() or "")
            except Exception:
                continue
        return "\n".join(parts).strip()
    except Exception:
        return ""