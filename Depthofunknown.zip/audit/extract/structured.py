from __future__ import annotations
import json, sqlite3, re, os
from datetime import datetime, timezone
from typing import Optional
from audit.io.schemas import Record, Activity, StateEvent

IDENT_KEYS = ("name", "email", "phone", "email_hash", "user_id", "first_name", "last_name", "username", "address")


def _ident_fields(d: dict) -> dict:
    out = {}
    for k in IDENT_KEYS:
        v = d.get(k)
        if v is None:
            v = d.get(k.replace("_", ""))
        if v is not None:
            out[k] = str(v).strip().lower() if k in ("email", "email_hash", "username") else str(v)
    return out


def _mk_record(system_id: str, resource_id: str, category: str, fields: dict, evidence_id: str, events=None) -> Record:
    return Record(
        record_uid=f"{system_id}::{resource_id}",
        system_id=system_id, resource_id=resource_id,
        data_category=category or "unknown",
        fields=fields, state_events=events or [],
        source_evidence_id=evidence_id,
    )


def parse_json(path: str, evidence_id: str, system_hint: str = "") -> tuple[list[Record], list[Activity]]:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        try:
            data = json.load(f)
        except Exception:
            return [], []
    records, activities = [], []
    items = data if isinstance(data, list) else data.get("records", data.get("items", [])) if isinstance(data, dict) else []
    if isinstance(data, dict) and not items:
        items = [data]
    for it in items:
        if not isinstance(it, dict):
            continue
        sys_id = str(it.get("system_id") or system_hint or "unknown")
        rid = str(it.get("resource_id") or it.get("id") or it.get("record_id") or "")
        if not rid:
            continue
        cat = str(it.get("data_category") or it.get("category") or "unknown")
        fields = _ident_fields(it)
        if "user_id" not in fields and it.get("user_id"):
            fields["user_id"] = str(it["user_id"])
        records.append(_mk_record(sys_id, rid, cat, fields, evidence_id))
    return records, activities


def parse_csv_evidence(path: str, evidence_id: str, system_hint: str = "") -> tuple[list[Record], list[Activity]]:
    import pandas as pd
    try:
        df = pd.read_csv(path, dtype=str).fillna("")
    except Exception:
        return [], []
    records, activities = [], []
    for _, row in df.iterrows():
        d = row.to_dict()
        sys_id = str(d.get("system_id") or system_hint or "unknown")
        rid = str(d.get("resource_id") or d.get("id") or d.get("record_id") or "")
        if not rid:
            continue
        cat = str(d.get("data_category") or d.get("category") or "unknown")
        fields = _ident_fields(d)
        records.append(_mk_record(sys_id, rid, cat, fields, evidence_id))
    return records, activities


def parse_sqlite_dump(path: str, evidence_id: str, system_hint: str = "") -> tuple[list[Record], list[Activity]]:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        sql = f.read()
    try:
        conn = sqlite3.connect(":memory:")
        conn.executescript(sql)
        cur = conn.cursor()
        tables = [r[0] for r in cur.execute(
            "SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        records, activities = [], []
        for t in tables:
            try:
                cur.execute(f'SELECT * FROM "{t}"')
                cols = [d[0] for d in cur.description]
                for r in cur.fetchall():
                    d = dict(zip(cols, r))
                    sys_id = str(d.get("system_id") or system_hint or t)
                    rid = str(d.get("resource_id") or d.get("id") or d.get("record_id") or d.get("pk") or "")
                    if not rid:
                        continue
                    cat = str(d.get("data_category") or d.get("category") or t)
                    fields = _ident_fields({k: (str(v) if v is not None else None) for k, v in d.items()})
                    if fields:
                        records.append(_mk_record(sys_id, rid, cat, fields, evidence_id))
            except Exception:
                continue
        conn.close()
        return records, activities
    except Exception:
        return [], []