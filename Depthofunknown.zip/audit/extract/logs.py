from __future__ import annotations
import re
from audit.io.schemas import Record, Activity, StateEvent

EVENT_PAT = re.compile(
    r"(?P<ts>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[^\s]*)\s+.*?(?P<event>CREATE|DELETE|REDACT|ANONYMIZE|RESTORE|SYNC_WRITE|INDEX|EXPORT)",
    re.IGNORECASE,
)
USER_PAT = re.compile(r"(?:user(?:_id)?|email|resource_id)=([^\s,;]+)", re.IGNORECASE)

DELETE_PAT = re.compile(r"\b(delete|deleted|purge|purged|remove|removed)\b", re.IGNORECASE)
SYNC_PAT = re.compile(r"\b(sync|replicate|replicated|mirror)\b", re.IGNORECASE)
RESTORE_PAT = re.compile(r"\b(restore|restored|backup|recovered)\b", re.IGNORECASE)


def _parse_ts(s: str):
    from datetime import datetime, timezone
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        try:
            return datetime.strptime(s[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
        except Exception:
            return None


def parse_log(path: str, evidence_id: str, system_hint: str = "") -> tuple[list[Record], list[Activity], list[str]]:
    records, activities, unmatched = [], [], []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            m = EVENT_PAT.search(line)
            ts = _parse_ts(m.group("ts")) if m else None
            if not ts:
                unmatched.append(line)
                continue
            event = m.group("event").upper()
            uid_m = USER_PAT.search(line)
            uid = uid_m.group(1).strip() if uid_m else ""
            sys_id = system_hint or "log"
            rid = f"log_{abs(hash(line))%10**8:08d}"
            fields = {}
            if "@" in uid:
                fields["email"] = uid.lower()
            elif uid:
                fields["user_id"] = uid
            records.append(Record(
                record_uid=f"{sys_id}::{rid}",
                system_id=sys_id, resource_id=rid,
                data_category="log", fields=fields,
                state_events=[StateEvent(ts=ts, event=event, evidence_id=evidence_id)],
                source_evidence_id=evidence_id,
            ))
            if event in ("SYNC_WRITE", "INDEX", "EXPORT"):
                activities.append(Activity(
                    activity_id=rid, system_id=sys_id,
                    kind="sync" if event == "SYNC_WRITE" else ("index" if event == "INDEX" else "export"),
                    status="active", started_at=ts,
                    scope={"user_refs": [uid.lower()] if uid else []},
                    evidence_id=evidence_id,
                ))
    return records, activities, unmatched